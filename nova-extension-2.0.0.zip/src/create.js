export function initCreate() {
  if (window.__novaCreateInitialized) return window.__novaCreateInstance;
  window.__novaCreateInitialized = true;
  const $ = id => document.getElementById(id);
  const host = $('studioResult');
  const state = { mode: 'image', imageData: '', imageName: '', objectUrl: '' };
  const esc = value => String(value || '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[char]));
  const palettes = [['#11182f','#635bff','#40d7c2','#f4b8ff'],['#281b2b','#ff7b72','#ffc857','#f5f0e6'],['#09252c','#32d6c5','#b2f7ef','#e9ff70'],['#211b3a','#a18aff','#fc78b8','#6dd6ff']];
  const choosePalette = text => palettes[[...String(text)].reduce((sum,char) => sum + char.charCodeAt(0),0) % palettes.length];
  const theme = text => { const value=String(text).toLowerCase(); return {stars:/space|star|cosmic|galaxy|moon/.test(value),waves:/ocean|sea|water|wave|coast/.test(value),botanical:/garden|flower|plant|forest|greenhouse|leaf/.test(value),sunset:/sunset|sunrise|dusk|dawn/.test(value)}; };

  function shapes(text, animated=false, width=1200, height=675, reference='') {
    const p=choosePalette(text),k=theme(text);
    const anim=animated?'<style>@keyframes drift{0%,100%{transform:translate(0,0)}50%{transform:translate(15px,-18px)}}@keyframes pulse{0%,100%{opacity:.45}50%{opacity:1}}.float{animation:drift 7s ease-in-out infinite}.glow{animation:pulse 4s ease-in-out infinite}</style>':'';
    const background=reference?`<image href="${reference}" x="0" y="0" width="${width}" height="${height}" preserveAspectRatio="xMidYMid slice"/>`:`<rect width="${width}" height="${height}" fill="${p[0]}"/>`;
    const scaleX=width/1200,scaleY=height/675;
    const art=`<g transform="scale(${scaleX} ${scaleY})">${k.waves?`<path d="M0 430 Q170 385 330 430 T660 420 T990 430 T1320 420 V675 H0Z" fill="${p[2]}" opacity=".7"/><path d="M0 500 Q180 450 360 500 T720 490 T1080 500 T1440 490 V675 H0Z" fill="${p[1]}" opacity=".82"/>`:k.botanical?Array.from({length:13},(_,i)=>`<path class="float" d="M${70+i*88} 610 Q${20+i*95} ${360+(i%4)*30} ${100+i*86} ${170+(i%3)*45} Q${180+i*75} 430 ${70+i*88} 610Z" fill="${p[1+i%3]}" opacity=".${4+i%5}"/>`).join(''):''}${(k.stars||!k.waves&&!k.botanical)?Array.from({length:34},(_,i)=>`<circle class="${i%5===0?'glow':''}" cx="${(i*173+71)%1200}" cy="${(i*89+45)%410}" r="${i%7===0?3:1.5}" fill="${p[2]}" opacity=".8"/>`).join(''):''}<circle class="${animated?'glow':''}" cx="860" cy="270" r="${k.sunset?95:65}" fill="${p[3]}" opacity=".9"/>${k.stars?`<ellipse cx="860" cy="270" rx="155" ry="56" fill="none" stroke="${p[2]}" stroke-width="3" opacity=".6" transform="rotate(-20 860 270)"/>`:''}<rect x="58" y="500" width="1084" height="118" rx="22" fill="#090d18" opacity=".68"/><text x="88" y="558" fill="#fff" font-size="40" font-family="system-ui,sans-serif" font-weight="700">${esc(String(text).split(/[,.!?;]/)[0].slice(0,48)||'Nova Create')}</text><text x="91" y="593" fill="${p[2]}" font-size="18" font-family="system-ui,sans-serif">${esc(String(text).slice(0,105))}</text></g>`;
    return `${anim}${background}${reference?'<rect width="100%" height="100%" fill="#111018" opacity=".16"/>':''}${art}`;
  }

  function svgDoc(text, ratio, animated, reference='') {
    const [width,height]=ratio==='portrait'?[675,1200]:ratio==='landscape'?[1200,675]:[900,900];
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">${shapes(text,animated,width,height,reference)}</svg>`;
  }

  function show(kind, text) {
    const ratio=$('imageRatio').value;
    const markup=svgDoc(text,kind==='image'?ratio:'landscape',kind==='video',kind==='image'?state.imageData:'');
    if(state.objectUrl) URL.revokeObjectURL(state.objectUrl);
    const blob=new Blob([markup],{type:'image/svg+xml'}),url=URL.createObjectURL(blob);state.objectUrl=url;
    host.replaceChildren();
    const art=document.createElement('article');art.className='generated-asset nova-svg-output';
    if(kind==='video'){const object=document.createElement('object');object.type='image/svg+xml';object.data=url;object.setAttribute('aria-label','Nova locally composed animated SVG');art.append(object);}
    else {const img=document.createElement('img');img.src=url;img.alt=`Locally composed Nova SVG: ${text.slice(0,100)}`;art.append(img);}
    const details=document.createElement('div');details.className='generated-art-details';
    const title=document.createElement('strong');title.textContent=kind==='video'?'Animated vector scene':'Your local artwork';
    const notice=document.createElement('p');notice.textContent=kind==='video'?'Motion is a self-contained animated SVG, not an MP4 or neural video.':state.imageData?`Your selected image is embedded in this SVG and stays local (${state.imageName}).`:'Artwork is composed from a small set of reusable vector shapes; prompt interpretation is limited.';
    const download=document.createElement('a');download.href=url;download.download=kind==='video'?'nova-motion.svg':'nova-artwork.svg';download.textContent='Download SVG';
    details.append(title,notice,download);art.append(details);host.append(art);host.scrollIntoView({behavior:'smooth',block:'nearest'});
  }

  function selectMode(mode) {
    state.mode=mode;
    document.querySelectorAll('[data-create-mode]').forEach(button=>{const selected=button.dataset.createMode===mode;button.classList.toggle('active',selected);button.setAttribute('aria-selected',String(selected));});
    $('imagePrompt').classList.toggle('hidden',mode!=='image');$('videoPrompt').classList.toggle('hidden',mode!=='video');
    $('generateImage').classList.toggle('hidden',mode!=='image');$('generateVideo').classList.toggle('hidden',mode!=='video');
    $('imagePrompt').setAttribute('aria-hidden',String(mode!=='image'));$('videoPrompt').setAttribute('aria-hidden',String(mode!=='video'));
  }
  document.querySelectorAll('[data-create-mode]').forEach(button=>button.addEventListener('click',()=>selectMode(button.dataset.createMode)));
  const videoTab=document.querySelector('[data-create-mode="video"]');if(videoTab){videoTab.lastChild.textContent=' Video';videoTab.title='Exports an animated SVG scene, not an MP4 video';}
  $('generateImage').addEventListener('click',()=>{const prompt=$('imagePrompt').value.trim();if(!prompt){$('imagePrompt').focus();$('imagePrompt').setCustomValidity('Describe your image first.');$('imagePrompt').reportValidity();setTimeout(()=>$('imagePrompt').setCustomValidity(''),1500);return;}show('image',prompt);});
  $('generateVideo').addEventListener('click',()=>{const prompt=$('videoPrompt').value.trim();if(!prompt){$('videoPrompt').focus();$('videoPrompt').setCustomValidity('Describe a motion scene first.');$('videoPrompt').reportValidity();setTimeout(()=>$('videoPrompt').setCustomValidity(''),1500);return;}show('video',prompt);});

  $('referenceImageFile').addEventListener('change',async event=>{
    const file=event.currentTarget.files?.[0];event.currentTarget.value='';if(!file)return;
    if(!/^image\/(png|jpeg|webp)$/.test(file.type)||file.size>5*1024*1024){host.textContent='Choose a PNG, JPG, or WebP image under 5 MB.';return;}
    const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file);});
    state.imageData=String(data);state.imageName=file.name;$('referencePreview').src=state.imageData;$('referenceName').textContent=file.name;$('referencePreviewWrap').classList.remove('hidden');$('imagePrompt').focus();
  });
  $('clearReference').addEventListener('click',()=>{state.imageData='';state.imageName='';$('referencePreview').removeAttribute('src');$('referencePreviewWrap').classList.add('hidden');});
  $('createSettingsButton').addEventListener('click',()=>{const panel=$('createSettings'),open=panel.classList.contains('hidden');panel.classList.toggle('hidden',!open);$('createSettingsButton').setAttribute('aria-expanded',String(open));});
  $('createEngineButton').addEventListener('click',()=>{host.innerHTML='<div class="create-inline-notice"><strong>Nova Local Studio</strong><span>This build composes vector art in your browser. It does not call an image or video model, and it does not require an API key.</span></div>';host.scrollIntoView({behavior:'smooth',block:'nearest'});});
  document.querySelectorAll('[data-discover-prompt]').forEach(card=>card.addEventListener('click',()=>{const prompt=card.dataset.discoverPrompt||'';selectMode('image');$('imagePrompt').value=prompt;show('image',prompt);}));

  $('backgroundTool').querySelector('strong').textContent='Background remover';
  $('textTool').querySelector('strong').textContent='Text remover';
  $('textTool').querySelector('small').textContent='AI inpainting unavailable offline';
  $('backgroundTool').addEventListener('click',()=>{if(!state.imageData){$('referenceImageFile').click();host.innerHTML='<div class="create-inline-notice"><strong>Add an image first</strong><span>Choose a PNG, JPG, or WebP. The local color-key tool can remove a fairly uniform background using the top-left pixel as its reference color.</span></div>';return;}removeFlatBackground().catch(error=>{host.textContent=error.message||'Could not process that image locally.';});});
  $('textTool').addEventListener('click',()=>{host.innerHTML='<div class="create-inline-notice"><strong>Text removal needs an inpainting model</strong><span>This keyless local build does not have an image inpainting model. For text added by Nova, edit the prompt and re-compose; imported images are left unchanged.</span></div>';host.scrollIntoView({behavior:'smooth',block:'nearest'});});

  async function removeFlatBackground() {
    const image=new Image();image.src=state.imageData;await image.decode();
    const scale=Math.min(1,1800/Math.max(image.naturalWidth,image.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));
    const context=canvas.getContext('2d',{willReadFrequently:true});context.drawImage(image,0,0,canvas.width,canvas.height);const frame=context.getImageData(0,0,canvas.width,canvas.height),pixels=frame.data;
    const sample=(x,y)=>{const i=(y*canvas.width+x)*4;return[pixels[i],pixels[i+1],pixels[i+2]];};const corners=[sample(0,0),sample(canvas.width-1,0),sample(0,canvas.height-1),sample(canvas.width-1,canvas.height-1)];
    const color=corners[0];let removed=0;
    for(let i=0;i<pixels.length;i+=4){const distance=Math.hypot(pixels[i]-color[0],pixels[i+1]-color[1],pixels[i+2]-color[2]);if(distance<42){pixels[i+3]=0;removed++;}else if(distance<76)pixels[i+3]=Math.round(pixels[i+3]*(distance-42)/34);}
    if(removed<canvas.width*canvas.height*.003){host.innerHTML='<div class="create-inline-notice"><strong>No flat background found</strong><span>This simple local tool works best when the top-left corner is a fairly uniform background color. It is not AI subject segmentation.</span></div>';return;}
    context.putImageData(frame,0,0);const url=canvas.toDataURL('image/png');const imageOut=document.createElement('img');imageOut.src=url;imageOut.alt='Image with similar top-left background pixels made transparent';
    const card=document.createElement('article');card.className='generated-asset';card.append(imageOut);const note=document.createElement('p');note.textContent='Local color-key result. Similar pixels to the top-left corner were made transparent; this is not AI subject segmentation.';const link=document.createElement('a');link.href=url;link.download='nova-background-keyed.png';link.textContent='Download transparent PNG';card.append(note,link);host.replaceChildren(card);host.scrollIntoView({behavior:'smooth',block:'nearest'});
  }

  selectMode('image');
  window.__novaCreateInstance=state;
  return state;
}
