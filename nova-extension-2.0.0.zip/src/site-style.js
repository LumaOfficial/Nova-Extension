(() => {
  const KEY = 'novaSiteStyles';
  const STYLE_ID = 'nova-saved-site-style';
  const apply = async () => {
    try {
      const result = await chrome.storage.local.get(KEY);
      const css = result?.[KEY]?.[location.origin];
      let style = document.getElementById(STYLE_ID);
      if (!css) {
        style?.remove();
        return;
      }
      if (!document.documentElement) return;
      if (!style) {
        style = document.createElement('style');
        style.id = STYLE_ID;
        style.dataset.nova = 'saved-site-style';
        (document.head || document.documentElement).appendChild(style);
      }
      style.textContent = css;
    } catch {
      // Permission can be revoked or storage can be unavailable; leave the page unchanged.
    }
  };
  if (document.documentElement) apply();
  else document.addEventListener('DOMContentLoaded', apply, { once: true });
})();
