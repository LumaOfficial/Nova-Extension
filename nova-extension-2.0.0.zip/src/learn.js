// Learn Lab — offline quiz, flashcards, XP, streak and badges built from the lesson library.
import { lessonPool, searchKnowledge } from './knowledge.js';
import { GLOSSARY } from './library.js';
import { store } from './store.js';

const STATS_KEY = 'novaLearnStats';
const LEVEL_NAMES = ['Curious', 'Apprentice', 'Scholar', 'Analyst', 'Synthesist', 'Polymath', 'Nova Mind'];

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}
function dayGap(a, b) {
  return Math.round((Date.parse(b) - Date.parse(a)) / 86400000);
}
function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}
function shuffle(list) {
  const copy = [...list];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}
function firstSentence(text) {
  return String(text || '').split(/(?<=[.!?])\s+/)[0];
}

export function lessonSubjects() {
  const map = new Map();
  lessonPool().forEach(lesson => {
    const subject = lesson.title.split(':')[0].trim();
    map.set(subject, (map.get(subject) || 0) + 1);
  });
  return [...map.entries()].map(([name, count]) => ({ name, count })).sort((a, b) => a.name.localeCompare(b.name));
}

function buildQuestions({ subject = 'Any', size = 5 } = {}) {
  const pool = subject === 'Any' ? lessonPool() : lessonPool().filter(lesson => lesson.title.startsWith(`${subject}:`));
  const source = pool.length >= 4 ? pool : lessonPool();
  const questions = [];
  const used = new Set();
  const glossaryPool = GLOSSARY.filter(item => source.some(lesson => lesson.text.toLowerCase().includes(item.term)));
  const bank = glossaryPool.length >= 3 ? glossaryPool : GLOSSARY;

  for (let i = 0; i < size * 4 && questions.length < size; i += 1) {
    const lesson = pick(source);
    if (used.has(lesson.title)) continue;
    used.add(lesson.title);
    const useGlossary = Math.random() < 0.45 && bank.length > 3;
    if (useGlossary) {
      const term = pick(bank);
      const wrong = shuffle(GLOSSARY.filter(item => item.term !== term.term)).slice(0, 3);
      const options = shuffle([term, ...wrong]);
      questions.push({
        kind: 'glossary',
        question: `What does “${term.term}” mean?`,
        options: options.map(item => item.def),
        answer: options.indexOf(term),
        explain: `${term.term}: ${term.def}`,
        lesson: lesson.title
      });
      continue;
    }
    const distractors = shuffle(lessonPool().filter(item => item.title !== lesson.title)).slice(0, 3);
    const options = shuffle([lesson, ...distractors]);
    questions.push({
      kind: 'lesson',
      question: `Which note matches this idea?\n“${firstSentence(lesson.text).slice(0, 155)}”`,
      options: options.map(item => item.title),
      answer: options.indexOf(lesson),
      explain: `${lesson.title} — ${firstSentence(lesson.text)}`,
      lesson: lesson.title
    });
  }
  return questions;
}

export function initLearn() {
  if (window.__novaLearnInitialized) return window.__novaLearnInstance;
  window.__novaLearnInitialized = true;

  const $ = id => document.getElementById(id);
  const state = {
    stats: { xp: 0, answered: 0, correct: 0, streak: 0, lastDay: '', best: 0, badges: [], daily: '', decks: 0 },
    quiz: null,
    index: 0,
    score: 0,
    streakRun: 0,
    daily: false
  };

  function level() {
    return { level: Math.floor(state.stats.xp / 100) + 1, into: state.stats.xp % 100, needed: 100 };
  }

  function renderStats() {
    const { level: lvl, into, needed } = level();
    $('learnLevel').textContent = String(lvl);
    $('learnLevelName').textContent = LEVEL_NAMES[Math.min(LEVEL_NAMES.length - 1, lvl - 1)];
    $('learnXp').textContent = String(state.stats.xp);
    $('learnXpNext').textContent = `${needed - into} XP to next`;
    $('learnStreak').textContent = String(state.stats.streak);
    const accuracy = state.stats.answered ? Math.round((state.stats.correct / state.stats.answered) * 100) : null;
    $('learnAccuracy').textContent = accuracy === null ? '—' : `${accuracy}%`;
    $('learnAnswered').textContent = `${state.stats.answered} answered`;
    const done = state.stats.daily === todayKey();
    $('dailyState').textContent = done ? 'Done today — come back tomorrow' : 'Answer 3 questions for bonus XP';
    $('startDaily').textContent = done ? 'Daily complete ✓' : 'Start daily challenge';
    $('startDaily').disabled = done;
    $('dailyBadge').textContent = done ? '✓ claimed' : '+30 XP';
    renderBadges();
  }

  const BADGES = [
    { id: 'first', label: 'First steps', hint: 'Answer one question', test: s => s.answered >= 1 },
    { id: 'ten', label: 'Ten down', hint: 'Answer 10 questions', test: s => s.answered >= 10 },
    { id: 'flawless', label: 'Flawless deck', hint: 'Finish a deck with every answer right', test: s => s.badges?.includes('flawless') },
    { id: 'streak3', label: 'Three-day streak', hint: 'Practise three days running', test: s => s.streak >= 3 },
    { id: 'xp250', label: '250 XP', hint: 'Keep stacking XP', test: s => s.xp >= 250 },
    { id: 'daily', label: 'Daily habit', hint: 'Finish the daily challenge', test: s => s.badges?.includes('daily') }
  ];

  function renderBadges() {
    const host = $('badgeList');
    if (!host) return;
    host.replaceChildren();
    BADGES.forEach(badge => {
      const unlocked = Boolean(badge.test(state.stats));
      const node = document.createElement('span');
      node.className = `badge ${unlocked ? 'unlocked' : ''}`;
      node.innerHTML = `<b>${unlocked ? '★' : '☆'}</b>`;
      const label = document.createElement('span');
      label.textContent = badge.label;
      label.title = badge.hint;
      node.append(label);
      host.append(node);
    });
  }

  function toast(text) {
    let host = document.getElementById('novaToast');
    if (!host) {
      host = document.createElement('div');
      host.id = 'novaToast';
      host.className = 'nova-toast';
      document.body.append(host);
    }
    host.textContent = text;
    host.classList.add('show');
    clearTimeout(host._timer);
    host._timer = setTimeout(() => host.classList.remove('show'), 2600);
  }

  function celebrate() {
    const burst = document.createElement('div');
    burst.className = 'nova-burst';
    burst.setAttribute('aria-hidden', 'true');
    document.body.append(burst);
    for (let i = 0; i < 18; i += 1) {
      const spark = document.createElement('span');
      spark.textContent = ['✦', '◆', '·', '✧'][i % 4];
      spark.style.setProperty('--x', `${Math.random() * 100}%`);
      spark.style.setProperty('--d', `${0.5 + Math.random() * 0.7}s`);
      spark.style.setProperty('--delay', `${Math.random() * 0.25}s`);
      burst.append(spark);
    }
    setTimeout(() => burst.remove(), 1800);
  }

  async function saveStats() {
    await store.set(STATS_KEY, state.stats);
    renderStats();
  }

  function bumpStreak() {
    const today = todayKey();
    if (state.stats.lastDay === today) return;
    const gap = state.stats.lastDay ? dayGap(state.stats.lastDay, today) : 99;
    state.stats.streak = gap === 1 ? state.stats.streak + 1 : 1;
    state.stats.lastDay = today;
  }

  function award(correct) {
    state.stats.answered += 1;
    if (correct) {
      state.stats.correct += 1;
      state.streakRun += 1;
      state.stats.best = Math.max(state.stats.best, state.streakRun);
      state.stats.xp += 10 + Math.min(10, state.streakRun * 2);
    } else {
      state.streakRun = 0;
      state.stats.xp += 2;
    }
    bumpStreak();
  }

  function renderQuiz() {
    const quiz = state.quiz;
    if (!quiz) return;
    const question = quiz.questions[state.index];
    $('quizPanel').classList.remove('hidden');
    $('quizProgress').textContent = `${state.daily ? 'Daily · ' : ''}Question ${state.index + 1} of ${quiz.questions.length}`;
    $('quizBarFill').style.width = `${(state.index / quiz.questions.length) * 100}%`;
    $('quizQuestion').textContent = question.question;
    $('quizFeedback').textContent = '';
    $('quizFeedback').className = 'quiz-feedback';
    $('quizNext').classList.add('hidden');
    const host = $('quizOptions');
    host.replaceChildren();
    question.options.forEach((option, index) => {
      const button = document.createElement('button');
      button.className = 'quiz-option';
      button.type = 'button';
      button.dataset.index = String(index);
      const key = document.createElement('span');
      key.className = 'quiz-key';
      key.textContent = 'ABCD'[index];
      const label = document.createElement('span');
      label.textContent = option;
      button.append(key, label);
      button.addEventListener('click', () => answer(index, button));
      host.append(button);
    });
  }

  function answer(index, button) {
    const quiz = state.quiz;
    if (!quiz || quiz.locked) return;
    const question = quiz.questions[state.index];
    quiz.locked = true;
    const correct = index === question.answer;
    [...$('quizOptions').children].forEach((node, i) => {
      node.disabled = true;
      if (i === question.answer) node.classList.add('correct');
      else if (i === index) node.classList.add('wrong');
    });
    button.classList.add(correct ? 'correct' : 'wrong');
    if (correct) state.score += 1;
    award(correct);
    $('quizFeedback').textContent = `${correct ? 'Correct.' : 'Not quite.'} ${question.explain}`;
    $('quizFeedback').className = `quiz-feedback ${correct ? 'good' : 'bad'}`;
    $('quizNext').classList.remove('hidden');
    $('quizNext').textContent = state.index + 1 >= quiz.questions.length ? 'See results' : 'Next question';
    saveStats();
  }

  function next() {
    const quiz = state.quiz;
    if (!quiz) return;
    quiz.locked = false;
    if (state.index + 1 >= quiz.questions.length) return finish();
    state.index += 1;
    renderQuiz();
  }

  async function finish() {
    const total = state.quiz.questions.length;
    const perfect = state.score === total;
    if (perfect) {
      state.stats.xp += 20;
      celebrate();
    }
    if (state.daily) {
      state.stats.daily = todayKey();
      state.stats.xp += 30;
      if (!state.stats.badges.includes('daily')) state.stats.badges.push('daily');
      toast('Daily challenge complete · +30 XP');
    }
    if (perfect && !state.stats.badges.includes('flawless')) {
      state.stats.badges.push('flawless');
      toast('Flawless deck · badge unlocked');
    }
    state.stats.decks += 1;
    $('quizBarFill').style.width = '100%';
    $('quizProgress').textContent = 'Deck complete';
    $('quizQuestion').textContent = `${state.score} / ${total} correct${perfect ? ' — flawless!' : ''}`;
    $('quizOptions').replaceChildren();
    $('quizFeedback').textContent = perfect ? 'Perfect run. Spacing this deck over the next few days will lock it in.' : 'Review the ones you missed, then run a fresh deck — retrieval beats rereading.';
    $('quizFeedback').className = 'quiz-feedback good';
    $('quizNext').classList.add('hidden');
    $('quizPanel').dataset.done = 'true';
    state.quiz = null;
    await saveStats();
  }

  function startQuiz(subject, size, daily = false) {
    const questions = buildQuestions({ subject, size });
    if (!questions.length) { toast('No questions for that topic yet.'); return; }
    state.quiz = { questions, locked: false };
    state.index = 0;
    state.score = 0;
    state.streakRun = 0;
    state.daily = daily;
    $('quizPanel').dataset.done = 'false';
    renderQuiz();
    $('quizPanel').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function quit() {
    state.quiz = null;
    $('quizPanel').classList.add('hidden');
  }

  $('startDeck')?.addEventListener('click', () => startQuiz($('deckTopic').value, Number($('deckSize').value)));
  $('startDaily')?.addEventListener('click', () => startQuiz('Any', 3, true));
  $('quizNext')?.addEventListener('click', next);
  $('quitQuiz')?.addEventListener('click', quit);

  const topicSelect = $('deckTopic');
  const chipHost = $('topicChips');
  function renderTopics() {
    if (!topicSelect) return;
    const subjects = lessonSubjects();
    topicSelect.replaceChildren();
    const all = document.createElement('option');
    all.value = 'Any';
    all.textContent = `Any subject · ${lessonPool().length} notes`;
    topicSelect.append(all);
    subjects.forEach(subject => {
      const option = document.createElement('option');
      option.value = subject.name;
      option.textContent = `${subject.name} · ${subject.count}`;
      topicSelect.append(option);
    });
    if (chipHost) {
      chipHost.replaceChildren();
      shuffle(subjects).slice(0, 8).forEach(subject => {
        const chip = document.createElement('button');
        chip.type = 'button';
        chip.className = 'topic-chip';
        chip.textContent = subject.name;
        chip.addEventListener('click', () => { topicSelect.value = subject.name; startQuiz(subject.name, Number($('deckSize').value || 5)); });
        chipHost.append(chip);
      });
    }
  }

  async function load() {
    const saved = await store.get(STATS_KEY, null);
    if (saved && typeof saved === 'object') {
      state.stats = { ...state.stats, ...saved, badges: Array.isArray(saved.badges) ? saved.badges : [] };
    }
    renderStats();
  }

  function open(subject) {
    renderTopics();
    renderStats();
    if (subject) startQuiz(subject, 5);
  }

  load();
  renderTopics();
  renderStats();
  const instance = { open, startQuiz, refresh: renderTopics, stats: () => ({ ...state.stats }) };
  window.__novaLearnInstance = instance;
  return instance;
}
