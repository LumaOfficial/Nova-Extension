// Text Lab — offline text utilities and the phrasebook, all local.
import { PHRASES, LANGUAGE_PACKS } from './library.js';

const ACTIONS = [
  { id: 'stats', label: 'Count words & characters' },
  { id: 'readtime', label: 'Reading time' },
  { id: 'upper', label: 'UPPERCASE' },
  { id: 'lower', label: 'lowercase' },
  { id: 'title', label: 'Title Case' },
  { id: 'sentence', label: 'Sentence case' },
  { id: 'reverse', label: 'Reverse' },
  { id: 'palindrome', label: 'Palindrome check' },
  { id: 'slug', label: 'Slug for a URL' },
  { id: 'trim', label: 'Tidy spacing' },
  { id: 'sort', label: 'Sort lines A→Z' },
  { id: 'dedupe', label: 'Remove duplicate lines' },
  { id: 'bullets', label: 'Turn lines into bullets' }
];

function titleCase(text) {
  return text.toLowerCase().replace(/\b[a-z]/g, letter => letter.toUpperCase());
}

export function runTextAction(id, input) {
  const text = String(input ?? '');
  const words = text.trim().split(/\s+/).filter(Boolean);
  switch (id) {
    case 'stats': {
      const unique = new Set(words.map(word => word.toLowerCase().replace(/[^a-z0-9]/g, '')).filter(Boolean));
      const sentences = text.split(/[.!?]+/).filter(part => part.trim()).length;
      return `${words.length} words\n${text.length} characters (${text.replace(/\s/g, '').length} without spaces)\n${unique.size} unique words\n${sentences} sentences\n${text.split('\n').length} lines`;
    }
    case 'readtime':
      return `About ${Math.max(1, Math.ceil(words.length / 220))} min reading\n${(words.length / 220).toFixed(1)} minutes at 220 wpm\n${Math.max(1, Math.ceil(words.length / 140))} min read aloud (140 wpm)`;
    case 'upper': return text.toUpperCase();
    case 'lower': return text.toLowerCase();
    case 'title': return titleCase(text);
    case 'sentence':
      return text.toLowerCase().replace(/(^\s*\w|[.!?]\s+\w)/g, letter => letter.toUpperCase());
    case 'reverse':
      return text.split('\n').map(line => [...line].reverse().join('')).join('\n');
    case 'palindrome': {
      const clean = text.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (!clean) return 'Add some text first.';
      const reversed = [...clean].reverse().join('');
      return clean === reversed
        ? `Yes — “${text.trim().slice(0, 60)}” reads the same backwards once punctuation and spacing are ignored.`
        : `No. Reversed it reads: ${reversed.slice(0, 120)}`;
    }
    case 'slug':
      return text.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').slice(0, 80);
    case 'trim':
      return text.replace(/[ \t]+/g, ' ').replace(/ ?\n ?/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
    case 'sort':
      return text.split('\n').map(line => line.trim()).filter(Boolean).sort((a, b) => a.localeCompare(b)).join('\n');
    case 'dedupe': {
      const seen = new Set();
      return text.split('\n').filter(line => {
        const key = line.trim();
        if (!key || seen.has(key)) return false;
        seen.add(key);
        return true;
      }).join('\n');
    }
    case 'bullets':
      return text.split('\n').map(line => line.trim()).filter(Boolean).map(line => `• ${line.replace(/^[-*•]\s*/, '')}`).join('\n');
    default: return text;
  }
}

export function initTools() {
  if (window.__novaToolsInitialized) return window.__novaToolsInstance;
  window.__novaToolsInitialized = true;
  const $ = id => document.getElementById(id);

  const actionHost = $('toolActions');
  if (actionHost) {
    actionHost.replaceChildren();
    ACTIONS.forEach(action => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'tool-action';
      button.textContent = action.label;
      button.addEventListener('click', () => {
        const input = $('toolInput').value;
        $('toolOutput').textContent = input.trim() ? runTextAction(action.id, input) : 'Add some text first, then pick a tool.';
        $('toolOutputCard').classList.remove('hidden');
      });
      actionHost.append(button);
    });
  }

  $('copyToolOutput')?.addEventListener('click', async event => {
    const output = $('toolOutput').textContent;
    if (!output) return;
    try {
      await navigator.clipboard.writeText(output);
      event.currentTarget.textContent = 'Copied';
      setTimeout(() => { event.currentTarget.textContent = 'Copy result'; }, 1400);
    } catch { event.currentTarget.textContent = 'Clipboard unavailable'; }
  });

  $('clearToolInput')?.addEventListener('click', () => {
    $('toolInput').value = '';
    $('toolOutput').textContent = '';
    $('toolOutputCard').classList.add('hidden');
    $('toolInput').focus();
  });

  const languageSelect = $('phraseLanguage');
  const list = $('phraseList');
  const search = $('phraseSearch');

  function renderPhrases() {
    if (!list) return;
    const language = languageSelect.value || 'Spanish';
    const query = (search?.value || '').toLowerCase().trim();
    const rows = PHRASES.filter(row => !query || row.en.toLowerCase().includes(query) || String(row[language]).toLowerCase().includes(query));
    list.replaceChildren();
    if (!rows.length) {
      const empty = document.createElement('p');
      empty.className = 'empty-state';
      empty.textContent = 'No phrase matches that search.';
      list.append(empty);
      return;
    }
    rows.forEach(row => {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'phrase-row';
      const left = document.createElement('span');
      left.className = 'phrase-en';
      left.textContent = row.en;
      const right = document.createElement('span');
      right.className = 'phrase-target';
      right.textContent = row[language] || '—';
      item.append(left, right);
      item.title = 'Click to copy';
      item.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(`${row.en} → ${row[language]}`);
          item.classList.add('copied');
          setTimeout(() => item.classList.remove('copied'), 900);
        } catch { /* clipboard blocked */ }
      });
      list.append(item);
    });
  }

  if (languageSelect) {
    languageSelect.replaceChildren();
    LANGUAGE_PACKS.forEach(language => {
      const option = document.createElement('option');
      option.value = language;
      option.textContent = language;
      languageSelect.append(option);
    });
  }
  languageSelect?.addEventListener('change', renderPhrases);
  search?.addEventListener('input', renderPhrases);
  renderPhrases();

  const instance = { runTextAction, renderPhrases, languages: LANGUAGE_PACKS };
  window.__novaToolsInstance = instance;
  return instance;
}
