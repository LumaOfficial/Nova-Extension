export function initRec() {
  if (window.__novaRecInitialized) return window.__novaRecInstance;
  window.__novaRecInitialized = true;
  const $ = id => document.getElementById(id);
  const state = { stream: null, recorder: null, chunks: [], blob: null, timer: null, startedAt: 0, previewUrl: '' };
  const setStatus = text => { $('recStatus').textContent = text; };
  function stopTracks() { state.stream?.getTracks().forEach(track => track.stop()); state.stream = null; }
  function downloadBlob(blob, name) {
    const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 30_000);
  }
  function renderRecording() {
    if (!state.blob) return;
    if (state.previewUrl) URL.revokeObjectURL(state.previewUrl);
    state.previewUrl = URL.createObjectURL(state.blob);
    $('recordingPreview').src = state.previewUrl;
    $('recordingPreviewWrap').classList.remove('hidden');
    $('recStatus').textContent = `Local recording ready (${(state.blob.size / 1024 / 1024).toFixed(1)} MiB). It has not been uploaded or transcribed.`;
  }
  function finishRecording(auto=false) {
    clearInterval(state.timer); state.timer = null;
    if (state.recorder && state.recorder.state !== 'inactive') state.recorder.stop();
    stopTracks();
    $('startCapture').disabled = false; $('stopCapture').disabled = true;
    if (auto) setStatus('The selected share ended. The recording remains local in this panel.');
  }
  $('startCapture').addEventListener('click', async () => {
    if (!navigator.mediaDevices?.getDisplayMedia || !window.MediaRecorder) { setStatus('This Chrome build does not support local screen/tab recording.'); return; }
    $('startCapture').disabled = true; setStatus('Choose a tab, window, or screen in Chrome’s picker. Recording starts only after you approve.');
    try {
      const audio = $('captureSource').value === 'screen-audio';
      state.stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio });
      if (audio && !state.stream.getAudioTracks().length) { stopTracks(); throw new Error('No audio track was shared. Choose a browser tab and enable Share tab audio.'); }
      const types=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm','audio/webm'];
      const mimeType=types.find(type=>MediaRecorder.isTypeSupported(type));
      state.recorder=new MediaRecorder(state.stream,mimeType?{mimeType}:undefined); state.chunks=[];
      state.recorder.addEventListener('dataavailable',event=>{if(event.data?.size)state.chunks.push(event.data);});
      state.recorder.addEventListener('stop',()=>{state.blob=new Blob(state.chunks,{type:state.recorder?.mimeType||'video/webm'});renderRecording();});
      state.recorder.addEventListener('error',()=>{finishRecording();setStatus('Chrome could not record this share. Your notes remain untouched.');});
      state.stream.getVideoTracks()[0]?.addEventListener('ended',()=>finishRecording(true),{once:true});
      state.recorder.start(1000); state.startedAt=Date.now(); $('stopCapture').disabled=false;
      setStatus(audio?'Recording your selected tab/screen locally. Stop when finished.':'Recording your selected screen locally without audio.');
      state.timer=setInterval(()=>{const seconds=Math.floor((Date.now()-state.startedAt)/1000);$('recTimer').textContent=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;},500);
    } catch(error) { stopTracks(); $('startCapture').disabled=false; setStatus(error?.message||'Capture was cancelled. Nothing is recording.'); }
  });
  $('stopCapture').addEventListener('click',()=>finishRecording(false));
  $('downloadRecording').addEventListener('click',()=>{if(state.blob)downloadBlob(state.blob,`nova-recording-${new Date().toISOString().replaceAll(':','-')}.webm`);});
  $('downloadNotes').addEventListener('click',()=>{const text=$('manualNotes').value.trim();if(!text){setStatus('Write some notes before downloading them.');return;}downloadBlob(new Blob([text+'\n'],{type:'text/plain;charset=utf-8'}),`nova-notes-${new Date().toISOString().slice(0,10)}.txt`);});
  state.refreshRecStatus=()=>setStatus(state.recorder?.state==='recording'?'Recording is active locally.':state.blob?'Local recording ready. No transcription is available in this extension-only build.':'Nothing is recording.');
  window.__novaRecInstance=state;
  return state;
}
