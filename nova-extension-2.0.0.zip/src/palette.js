// Command palette — one keystroke to every Nova action.

export function initPalette({ actions = [], onSubmit = null } = {}) {
  if (window.__novaPaletteInitialized) return window.__novaPaletteInstance;
  window.__novaPaletteInitialized = true;
  const $ = id => document.getElementById(id);
  const input = $('paletteInput');
  const list = $('paletteList');
  const root = $('palette');
  let filtered = [];
  let cursor = 0;
  let provider = () => actions;

  function score(haystack, needle) {
    const hay = haystack.toLowerCase();
    const target = needle.toLowerCase().trim();
    if (!target) return 1;
    if (hay.startsWith(target)) return 100;
    if (hay.includes(target)) return 70;
    let index = 0;
    let hits = 0;
    for (const char of hay) {
      if (char === target[index]) { hits += 1; index += 1; }
      if (index >= target.length) break;
    }
    return index >= target.length ? 30 + hits : 0;
  }

  function render() {
    const query = input.value;
    const pool = provider();
    filtered = pool
      .map(action => ({ action, points: Math.max(score(action.label, query), score(action.hint || '', query) * 0.4, score(action.keywords || '', query) * 0.6) }))
      .filter(entry => entry.points > 0)
      .sort((a, b) => b.points - a.points)
      .slice(0, 40)
      .map(entry => entry.action);
    cursor = 0;
    list.replaceChildren();
    if (!filtered.length) {
      const empty = document.createElement('p');
      empty.className = 'palette-empty';
      empty.textContent = query.trim() ? `No command matches “${query.trim()}”. Press Enter to ask Nova instead.` : 'Nothing here yet.';
      list.append(empty);
      return;
    }
    filtered.forEach((action, index) => {
      const row = document.createElement('button');
      row.type = 'button';
      row.className = `palette-row${index === cursor ? ' active' : ''}`;
      const glyph = document.createElement('span');
      glyph.className = 'palette-glyph';
      glyph.textContent = action.glyph || '›';
      const body = document.createElement('span');
      body.className = 'palette-body';
      const label = document.createElement('strong');
      label.textContent = action.label;
      body.append(label);
      if (action.hint) {
        const hint = document.createElement('small');
        hint.textContent = action.hint;
        body.append(hint);
      }
      const tag = document.createElement('span');
      tag.className = 'palette-tag';
      tag.textContent = action.group || '';
      row.append(glyph, body, tag);
      row.addEventListener('click', () => run(action));
      row.addEventListener('mousemove', () => {
        if (cursor !== index) {
          cursor = index;
          [...list.children].forEach((node, i) => node.classList?.toggle('active', i === index));
        }
      });
      list.append(row);
    });
  }

  function move(delta) {
    if (!filtered.length) return;
    cursor = (cursor + delta + filtered.length) % filtered.length;
    [...list.children].forEach((node, index) => node.classList?.toggle('active', index === cursor));
    list.children[cursor]?.scrollIntoView({ block: 'nearest' });
  }

  function run(action) {
    close();
    try { action.run(input.value.trim()); } catch (error) { console.warn('Nova command failed', error); }
  }

  function open(options = {}) {
    if (typeof options.provider === 'function') provider = options.provider;
    root.classList.remove('hidden');
    input.value = options.query || '';
    input.focus();
    render();
  }
  function close() {
    root.classList.add('hidden');
    input.value = '';
    provider = () => actions;
  }
  function toggle() {
    if (root.classList.contains('hidden')) open();
    else close();
  }

  input.addEventListener('input', render);
  input.addEventListener('keydown', event => {
    if (event.key === 'ArrowDown') { event.preventDefault(); move(1); }
    else if (event.key === 'ArrowUp') { event.preventDefault(); move(-1); }
    else if (event.key === 'Enter') {
      event.preventDefault();
      if (filtered.length) run(filtered[cursor]);
      else if (input.value.trim() && typeof onSubmit === 'function') { const query = input.value.trim(); close(); onSubmit(query); }
    } else if (event.key === 'Escape') close();
  });
  root.addEventListener('mousedown', event => { if (event.target === root) close(); });
  document.addEventListener('keydown', event => {
    const mod = event.metaKey || event.ctrlKey;
    if (mod && event.key.toLowerCase() === 'k') { event.preventDefault(); toggle(); }
    else if (event.key === 'Escape' && !root.classList.contains('hidden')) close();
  });

  const instance = { open, close, toggle, register: extra => { actions.push(...extra); } };
  window.__novaPaletteInstance = instance;
  return instance;
}
