// Nova Brain — local reasoning engine.
// Everything here is deterministic, offline and inspectable: no API keys, no hosted model.
// The LLM (when Chrome exposes one) still handles open-ended language; this engine covers
// calculations, conversions, lookups, quizzes, text work and the curated library.

import { GLOSSARY, PHRASES, FUN_FACTS, LANGUAGE_PACKS } from './library.js';
import { answerOffline, calculate, lessonPool, searchKnowledge } from './knowledge.js';

export const PERSONAS = [
  { id: 'tutor', name: 'Tutor', glyph: '✦', blurb: 'Patient explanations with checks for understanding' },
  { id: 'coach', name: 'Coach', glyph: '◈', blurb: 'Short, direct next actions' },
  { id: 'coder', name: 'Coder', glyph: '‹›', blurb: 'Code first, theory second' },
  { id: 'editor', name: 'Editor', glyph: '⌁', blurb: 'Tighter wording and clearer structure' },
  { id: 'socratic', name: 'Socratic', glyph: '?', blurb: 'Answers with better questions' },
  { id: 'buddy', name: 'Buddy', glyph: '☺', blurb: 'Friendly, plain and a bit playful' }
];

export function getPersona(id) {
  return PERSONAS.find(persona => persona.id === id) || PERSONAS[0];
}

/* ------------------------------- utilities ------------------------------- */

const JOKES = [
  'Why did the developer go broke? They used up all their cache.',
  'Why do programmers prefer dark mode? Because light attracts bugs.',
  'There are 10 kinds of people: those who understand binary and those who do not.',
  'A SQL query walks into a bar, approaches two tables and asks: “May I join you?”',
  'Why was the maths book sad? It had too many problems.',
  'I changed my password to “incorrect”. Now the computer tells me my password is incorrect.',
  'A byte walks into a bar looking down. The bartender asks what is wrong. “Parity bit — I think I lost a bit.”'
];

const CODE_HELP = [
  { keys: ['closure', 'closures'], text: `A closure is a function that keeps access to the scope where it was created, even after that scope finished running.\n\nlet count = 0; const next = () => ++count;\n// next keeps its own private count\n\nUses: private state, callbacks, once-only setup. Cost: captured variables live as long as the function does.` },
  { keys: ['promise', 'async await', 'async/await'], text: `A Promise represents a value that will arrive later: pending → fulfilled or rejected.\n\nasync function load() {\n  try {\n    const res = await fetch(url);\n    if (!res.ok) throw new Error('HTTP ' + res.status);\n    return await res.json();\n  } catch (error) {\n    console.error(error);\n  }\n}\n\nawait pauses that function only; it does not block the page. Always handle rejection.` },
  { keys: ['var let const', 'let vs var', 'const'], text: `Use const by default, let when reassigning, and avoid var. const prevents rebinding, not mutation — a const array can still be pushed to. var is function-scoped and hoisted; let and const are block-scoped and live in the temporal dead zone until initialised.` },
  { keys: ['== vs ===', 'equality', 'strict equality'], text: `=== compares without type conversion; == converts first, so "1" == 1 is true and "" == 0 is true. Prefer === and be explicit about conversions. One legitimate exception: value == null is a handy check for both null and undefined.` },
  { keys: ['hoisting', 'temporal dead zone'], text: `Function declarations are hoisted with their body; var declarations are hoisted but start as undefined; let/const are hoisted but unusable until their line runs (temporal dead zone). Hoisting explains why calling a function before its declaration usually works but reading a let too early throws.` },
  { keys: ['map vs foreach', 'foreach', 'map method'], text: `map returns a new array of the same length; forEach returns undefined and is for side effects. Use map when you want the transformed values, and filter before map when some items do not apply.` },
  { keys: ['debounce', 'throttle'], text: `Debounce waits until calls stop (search-as-you-type). Throttle runs at most once per interval (scroll handlers).\n\nconst debounce = (fn, ms = 300) => {\n  let t;\n  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };\n};` },
  { keys: ['flexbox', 'flex', 'grid vs flex'], text: `Flexbox lays out one dimension: display:flex; gap:12px; align-items:center; justify-content:space-between. Grid handles two: display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));. Use flex for a row of controls, grid for page or card layouts.` },
  { keys: ['specificity', 'css specificity'], text: `Specificity order: inline styles > ids > classes/attributes/pseudo-classes > elements. Equal specificity → later rule wins. !important beats normal rules and is a maintenance smell. Prefer low-specificity classes and CSS custom properties for themes.` },
  { keys: ['box-sizing', 'box model'], text: `The box model is content + padding + border + margin. box-sizing: border-box makes width include padding and border, which is what most layouts expect. Add *, *::before, *::after { box-sizing: border-box; } once.` },
  { keys: ['join types', 'sql join', 'inner join', 'left join'], text: `INNER JOIN keeps rows matching in both tables. LEFT JOIN keeps all left rows and fills unmatched right columns with NULL. RIGHT JOIN is the mirror; FULL OUTER JOIN keeps both sides. Filtering a left-joined table in WHERE can silently turn it into an inner join — put the condition in ON instead.` },
  { keys: ['regex for email', 'email regex', 'validate email'], text: `Email validation by regex is approximate. A practical check: /^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$/. Real validation is delivery — send a confirmation link instead of rejecting unusual but valid addresses.` },
  { keys: ['list comprehension', 'python comprehension'], text: `squares = [n * n for n in range(10) if n % 2 == 0]\n# equivalent to a loop that appends n*n when the condition holds\n\nDict version: {k: v for k, v in pairs}. Keep it to one readable line; use a normal loop when it gets longer.` },
  { keys: ['f-string', 'python format', 'format string'], text: `Python f-strings interpolate inline: f"{name} scored {score:.2f}%". After the colon comes the format spec: .2f for two decimals, a comma for thousands separators, >10 to right-align in ten characters. JavaScript template literals do the same job with a dollar-brace placeholder inside a backtick string.` },
  { keys: ['dictionary get', 'python dict', 'dict get'], text: `Use dict.get(key, default) instead of indexing when a key may be missing: value = counts.get(word, 0) + 1. Indexing raises KeyError; get returns the default. Use setdefault or collections.Counter for counting.` },
  { keys: ['big o', 'complexity', 'time complexity'], text: `Common growth rates, cheapest first: O(1) constant, O(log n) binary search, O(n) single pass, O(n log n) good sorting, O(n²) nested loops, O(2ⁿ) naive subsets. Big-O describes how work grows with input size; constants still matter in practice.` },
  { keys: ['binary search big o', 'binary search complexity'], text: `Binary search is O(log n): each comparison halves the remaining range, so 1,000,000 items need about 20 comparisons. It requires sorted data. Linear search is O(n) but works on unsorted data and is faster for tiny inputs.` },
  { keys: ['git undo', 'undo commit', 'git reset'], text: `Undo the last commit but keep the changes: git reset --soft HEAD~1. Keep changes staged: --mixed (default). Throw the changes away: --hard (destructive). Already pushed? Prefer git revert <sha>, which adds a new commit instead of rewriting history.` },
  { keys: ['git branch', 'create branch', 'switch branch'], text: `Create and switch: git switch -c feature/name. List: git branch. Switch back: git switch main. Delete a merged branch: git branch -d feature/name. Push a new branch: git push -u origin feature/name.` },
  { keys: ['git stash', 'stash'], text: `git stash pushes uncommitted work aside; git stash pop restores it. git stash list shows entries. Use it to switch branches quickly, not as long-term storage.` },
  { keys: ['merge vs rebase', 'rebase'], text: `Merge preserves history and adds a merge commit; rebase replays your commits on top of the target for a linear history. Never rebase commits other people already pulled. Rebase your own local work before opening a pull request.` },
  { keys: ['python virtualenv', 'venv', 'virtual environment'], text: `python -m venv .venv && source .venv/bin/activate creates and enters an isolated environment; pip install -r requirements.txt installs pinned dependencies. Deactivate leaves it. Commit requirements.txt, never the .venv folder.` },
  { keys: ['npm install error', 'node_modules', 'package lock'], text: `Delete node_modules and reinstall from the lockfile: rm -rf node_modules && npm ci. Use npm ci (or pnpm install --frozen-lockfile) in automation so installs match the lockfile exactly. Never edit the lockfile by hand.` },
  { keys: ['cors', 'cross origin'], text: `CORS is enforced by the browser, not the server. The server must return Access-Control-Allow-Origin for your page's origin (plus Allow-Credentials for cookies, and a successful OPTIONS preflight). A proxy avoids CORS entirely by making the request same-origin.` }
];

function normalize(text) {
  return String(text || '').toLowerCase().replace(/[’']/g, '').replace(/[^a-z0-9+*/^().%\s-]/g, ' ').replace(/\s+/g, ' ').trim();
}
function cleanQuestion(prompt) {
  return String(prompt || '')
    .replace(/\n\s*Requested explanation level:[\s\S]*$/i, '')
    .replace(/\[Untrusted page context[\s\S]*$/i, '')
    .replace(/CURATED REFERENCE NOTES[\s\S]*$/i, '')
    .trim()
    .slice(0, 1200);
}
function fmt(value, digits = 6) {
  if (!Number.isFinite(value)) return '—';
  const rounded = Number(value.toFixed(digits));
  return String(rounded);
}
function money(value) {
  return Number(value).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
function titleCase(text) {
  return String(text).toLowerCase().replace(/\b[a-z]/g, letter => letter.toUpperCase());
}
function stripTrailingQuestion(text) {
  return String(text || '').replace(/[?!.]+$/g, '').trim();
}
function bullet(items) {
  return items.filter(Boolean).map(item => `• ${item}`).join('\n');
}
function parseNumbers(text) {
  return (String(text || '').match(/-?\d+(?:\.\d+)?/g) || []).map(Number).filter(Number.isFinite);
}

/* ------------------------------ unit conversion ------------------------------ */

const UNIT_FAMILIES = {
  length: { base: 'm', units: { m: 1, meter: 1, meters: 1, metre: 1, metres: 1, km: 1000, kilometer: 1000, kilometers: 1000, kilometre: 1000, cm: 0.01, centimeter: 0.01, centimeters: 0.01, mm: 0.001, millimeter: 0.001, millimeters: 0.001, mile: 1609.344, miles: 1609.344, mi: 1609.344, yard: 0.9144, yards: 0.9144, yd: 0.9144, foot: 0.3048, feet: 0.3048, ft: 0.3048, inch: 0.0254, inches: 0.0254, nauticalmile: 1852 } },
  mass: { base: 'kg', units: { kg: 1, kilogram: 1, kilograms: 1, g: 0.001, gram: 0.001, grams: 0.001, mg: 1e-6, milligram: 1e-6, milligrams: 1e-6, lb: 0.45359237, lbs: 0.45359237, pound: 0.45359237, pounds: 0.45359237, oz: 0.028349523125, ounce: 0.028349523125, ounces: 0.028349523125, stone: 6.35029318, ton: 1000, tonne: 1000, tonnes: 1000 } },
  volume: { base: 'l', units: { l: 1, liter: 1, liters: 1, litre: 1, litres: 1, ml: 0.001, milliliter: 0.001, milliliters: 0.001, gallon: 3.785411784, gallons: 3.785411784, quart: 0.946352946, quarts: 0.946352946, pint: 0.473176473, pints: 0.473176473, cup: 0.2365882365, cups: 0.2365882365, tbsp: 0.0147867648, tsp: 0.00492892159, floz: 0.0295735296 } },
  data: { base: 'byte', units: { b: 1, byte: 1, bytes: 1, kb: 1000, kilobyte: 1000, kilobytes: 1000, mb: 1e6, megabyte: 1e6, megabytes: 1e6, gb: 1e9, gigabyte: 1e9, gigabytes: 1e9, tb: 1e12, terabyte: 1e12, terabytes: 1e12, kib: 1024, mib: 1048576, gib: 1073741824, tib: 1099511627776 } },
  time: { base: 's', units: { s: 1, sec: 1, second: 1, seconds: 1, min: 60, minute: 60, minutes: 60, h: 3600, hr: 3600, hour: 3600, hours: 3600, day: 86400, days: 86400, week: 604800, weeks: 604800, year: 31557600, years: 31557600 } },
  speed: { base: 'm/s', units: { mps: 1, 'm/s': 1, kmh: 1 / 3.6, 'km/h': 1 / 3.6, kph: 1 / 3.6, mph: 0.44704, knot: 0.514444, knots: 0.514444 } },
  area: { base: 'm²', units: { m2: 1, sqm: 1, km2: 1e6, cm2: 1e-4, hectare: 10000, hectares: 10000, acre: 4046.8564224, acres: 4046.8564224, sqft: 0.09290304, sqmi: 2589988.110336 } }
};

const TEMPERATURE = { c: 'celsius', celsius: 'celsius', f: 'fahrenheit', fahrenheit: 'fahrenheit', k: 'kelvin', kelvin: 'kelvin' };

function unitLookup(token) {
  const key = String(token || '').toLowerCase().replace(/[°.\s]/g, '');
  if (!key) return null;
  if (TEMPERATURE[key]) return { family: 'temperature', unit: TEMPERATURE[key], factor: 1 };
  for (const [family, data] of Object.entries(UNIT_FAMILIES)) {
    if (data.units[key] !== undefined) return { family, unit: key, factor: data.units[key] };
  }
  return null;
}
function convertValue(value, from, to) {
  if (from.family === 'temperature' || to.family === 'temperature') {
    if (from.family !== 'temperature' || to.family !== 'temperature') return null;
    const celsius = from.unit === 'celsius' ? value : from.unit === 'fahrenheit' ? (value - 32) * 5 / 9 : value - 273.15;
    if (to.unit === 'celsius') return celsius;
    if (to.unit === 'fahrenheit') return celsius * 9 / 5 + 32;
    return celsius + 273.15;
  }
  if (from.family !== to.family) return null;
  return (value * from.factor) / to.factor;
}

/* ---------------------------------- dates ---------------------------------- */

const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function parseDate(input) {
  const text = String(input || '').toLowerCase().replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
  if (!text) return null;
  if (/^today$/.test(text)) return new Date();
  if (/^tomorrow$/.test(text)) { const d = new Date(); d.setDate(d.getDate() + 1); return d; }
  if (/^yesterday$/.test(text)) { const d = new Date(); d.setDate(d.getDate() - 1); return d; }
  const iso = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (iso) return new Date(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]));
  const slash = text.match(/^(\d{1,2})[/.](\d{1,2})[/.](\d{4})$/);
  if (slash) return new Date(Number(slash[3]), Number(slash[1]) - 1, Number(slash[2]));
  const named = text.match(/^(?:(\d{1,2})\s+)?([a-z]+)\s+(\d{1,2})?\s*(\d{4})?$/);
  if (named) {
    const month = MONTHS.findIndex(name => name.startsWith(named[2].slice(0, 3)));
    if (month >= 0) {
      const day = Number(named[3] || named[1] || 1);
      const year = Number(named[4] || new Date().getFullYear());
      return new Date(year, month, day);
    }
  }
  return null;
}
function dateLabel(date) {
  return date.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}
function dayDiff(a, b) {
  const day = 24 * 60 * 60 * 1000;
  const start = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
  const end = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
  return Math.round((end - start) / day);
}

/* --------------------------------- skills --------------------------------- */

function mathSkill(q) {
  const text = stripTrailingQuestion(q).replace(/,/g, '');

  // percentages
  let match = text.match(/(-?[\d.]+)\s*(?:%|percent)\s*(?:off|less)\s*(?:of\s*)?\$?(-?[\d.]+)/i);
  if (match) {
    const percent = Number(match[1]), base = Number(match[2]);
    const saving = base * percent / 100;
    return { skill: 'percent', text: `◆ ${percent}% off ${base}\n\nSaving: ${fmt(saving)}\nYou pay: ${fmt(base - saving)}\n\nA ${percent}% discount means paying ${fmt(100 - percent)}% of the price, so a quick check is ${fmt(base)} × ${fmt((100 - percent) / 100)}.`, followUps: ['What is sales tax on that?', 'Explain percentages', 'Quiz me on percentages'] };
  }
  match = text.match(/(-?[\d.]+)\s*(?:%|percent)\s*(?:tip|tax|markup|increase|rise)\s*(?:on|of|to)?\s*\$?(-?[\d.]+)/i);
  if (match) {
    const percent = Number(match[1]), base = Number(match[2]);
    const extra = base * percent / 100;
    return { skill: 'percent', text: `◆ ${percent}% of ${base}\n\n${percent}% is ${fmt(extra)}, giving a total of ${fmt(base + extra)}.\n\nMethod: convert the percent to a decimal (${percent}% = ${fmt(percent / 100)}) and multiply.`, followUps: ['Explain percentages', 'Quiz me on percentages', 'Convert 5 km to miles'] };
  }
  match = text.match(/(-?[\d.]+)\s*(?:%|percent)\s*of\s*\$?(-?[\d.]+)/i);
  if (match) {
    const percent = Number(match[1]), base = Number(match[2]);
    return { skill: 'percent', text: `◆ ${percent}% of ${base}\n\n${fmt(base * percent / 100)}\n\n${percent}% means ${percent} per hundred, so multiply ${base} by ${fmt(percent / 100)}.`, followUps: ['What is 20% off 45?', 'Explain percentages', 'Quiz me on percentages'] };
  }
  match = text.match(/(?:increase|decrease|raise|lower)\s+\$?(-?[\d.]+)\s+by\s+(-?[\d.]+)\s*(?:%|percent)/i);
  if (match) {
    const base = Number(match[1]), percent = Number(match[2]);
    const up = /increase|raise/i.test(text);
    const change = base * percent / 100;
    return { skill: 'percent', text: `◆ ${up ? 'Increase' : 'Decrease'} ${base} by ${percent}%\n\n${fmt(base)} ${up ? '+' : '−'} ${fmt(change)} = ${fmt(up ? base + change : base - change)}\n\nPercent change always uses the original amount as the base.`, followUps: ['Explain percentages', 'What is 15% of 200?'] };
  }

  // unit conversion
  match = text.match(/(-?[\d.]+)\s*([a-z°\/]+)\s*(?:to|in|into|as)\s*([a-z°\/]+)$/i) || text.match(/how many\s+([a-z°\/]+)\s+(?:are\s+)?in\s+(-?[\d.]+)\s*([a-z°\/]+)/i);
  if (match) {
    const swap = /^how many/i.test(match[0]);
    const value = Number(swap ? match[2] : match[1]);
    const from = unitLookup(swap ? match[3] : match[2]);
    const to = unitLookup(swap ? match[1] : match[3]);
    const result = from && to ? convertValue(value, from, to) : null;
    if (result !== null && Number.isFinite(result)) {
      return { skill: 'convert', text: `◆ ${fmt(value)} ${from.unit} in ${to.unit}\n\n${fmt(value)} ${from.unit} = ${fmt(result)} ${to.unit}\n\nI convert through a base unit (${(UNIT_FAMILIES[from.family]?.base) || from.unit}), so the same method works for any pair in that family.`, followUps: ['Convert 100 f to c', 'Explain unit conversion', 'Quiz me on measurement'] };
    }
  }

  // proportion word problem
  match = text.match(/if\s+(-?[\d.]+)\s+(.{0,28}?)\s+(?:cost|costs|is|are|makes|make|produces?|yields?)\s+\$?(-?[\d.]+).*?how (?:much|many)\s+(?:do|does|will|would)?\s*(-?[\d.]+)/i);
  if (match) {
    const a = Number(match[1]), cost = Number(match[3]), b = Number(match[4]);
    if (a !== 0) {
      const unit = cost / a;
      return { skill: 'ratio', text: `◆ Proportion\n\nUnit value: ${fmt(cost)} ÷ ${fmt(a)} = ${fmt(unit)}\nFor ${fmt(b)}: ${fmt(unit)} × ${fmt(b)} = ${fmt(unit * b)}\n\nThe unit-rate method works whenever the same ratio applies.`, followUps: ['Explain ratios', 'What is 15% of 200?', 'Quiz me on ratios'] };
    }
  }

  // statistics
  match = text.match(/(average|mean|median|mode|range|total|sum)\s+(?:of|for)\s+(?:the numbers\s+)?([\d.\s,+-]+)/i);
  if (match) {
    const kind = match[1].toLowerCase();
    const values = parseNumbers(match[2]);
    if (values.length >= 2) {
      const sorted = [...values].sort((a, b) => a - b);
      const sum = values.reduce((acc, value) => acc + value, 0);
      const mean = sum / values.length;
      const median = sorted.length % 2 ? sorted[(sorted.length - 1) / 2] : (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2;
      const counts = new Map();
      values.forEach(value => counts.set(value, (counts.get(value) || 0) + 1));
      const top = Math.max(...counts.values());
      const modes = [...counts.entries()].filter(([, count]) => count === top).map(([value]) => value);
      const result = kind === 'sum' || kind === 'total' ? fmt(sum) : kind === 'median' ? fmt(median) : kind === 'mode' ? modes.join(', ') : kind === 'range' ? fmt(sorted.at(-1) - sorted[0]) : fmt(mean);
      return { skill: 'statistics', text: `◆ ${kind[0].toUpperCase() + kind.slice(1)} of ${values.length} values\n\n${result}\n\nData: ${sorted.join(', ')}\nSum ${fmt(sum)} · mean ${fmt(mean)} · median ${fmt(median)} · mode ${modes.join(', ')} · range ${fmt(sorted.at(-1) - sorted[0])}`, followUps: ['Explain mean vs median', 'Quiz me on statistics', 'What is standard deviation?'] };
    }
  }

  // gcd / lcm / prime / factorial / fibonacci
  match = text.match(/(gcd|hcf|greatest common divisor|lcm|least common multiple)\s*(?:of\s*)?(-?[\d.]+)\s*(?:and|,)\s*(-?[\d.]+)/i);
  if (match) {
    const a = Math.abs(Math.round(Number(match[2]))), b = Math.abs(Math.round(Number(match[3])));
    const gcd = (x, y) => (y === 0 ? x : gcd(y, x % y));
    const g = gcd(a, b);
    const out = /lcm/i.test(match[1]) ? (g ? (a * b) / g : 0) : g;
    return { skill: 'number', text: `◆ ${/lcm/i.test(match[1]) ? 'LCM' : 'GCD'} of ${a} and ${b}\n\n${out}\n\n${/lcm/i.test(match[1]) ? `LCM = (a × b) ÷ GCD = (${a} × ${b}) ÷ ${g}.` : 'The Euclidean algorithm repeats remainders until zero; the last non-zero remainder is the GCD.'}`, followUps: ['Is 91 prime?', 'Quiz me on number theory', 'Explain fractions'] };
  }
  match = text.match(/is\s+(-?[\d.]+)\s+(?:a\s+)?prime/i) || text.match(/prime check\s+(-?[\d.]+)/i);
  if (match) {
    const n = Math.round(Number(match[1]));
    let prime = n > 1;
    for (let i = 2; i * i <= n && prime; i += 1) if (n % i === 0) prime = false;
    return { skill: 'number', text: `◆ Is ${n} prime?\n\n${prime ? `Yes — ${n} has no divisors other than 1 and itself.` : `No — ${n}${n < 2 ? ' is not greater than 1' : ' has a factor between 2 and ' + fmt(Math.sqrt(n), 2)}.`}\n\nTest divides up to √${n} ≈ ${fmt(Math.sqrt(Math.abs(n)), 2)}; anything bigger would pair with a smaller factor.`, followUps: ['Find the factors of 84', 'Is 97 prime?', 'Quiz me on number theory'] };
  }
  match = q.match(/(-?[\d.]+)!|factorial of (-?[\d.]+)/i);
  if (match) {
    const n = Math.round(Number(match[1] || match[2]));
    if (n >= 0 && n <= 170) {
      let value = 1;
      for (let i = 2; i <= n; i += 1) value *= i;
      return { skill: 'number', text: `◆ ${n}!\n\n${fmt(value, 4)}\n\nFactorial multiplies every whole number from 1 to ${n}; 0! is defined as 1 by convention so that counting formulas work.`, followUps: ['Explain permutations', 'Quiz me on combinatorics'] };
    }
  }
  match = text.match(/factors of (-?[\d.]+)/i);
  if (match) {
    const n = Math.abs(Math.round(Number(match[1])));
    const factors = [];
    for (let i = 1; i * i <= n; i += 1) if (n % i === 0) { factors.push(i); if (i !== n / i) factors.push(n / i); }
    factors.sort((a, b) => a - b);
    return { skill: 'number', text: `◆ Factors of ${n}\n\n${factors.slice(0, 40).join(', ')}\n\n${factors.length} factors in total. A number is prime exactly when its only factors are 1 and itself.`, followUps: ['Is 97 prime?', 'Explain prime numbers', 'Quiz me on number theory'] };
  }

  // geometry
  match = text.match(/(area|circumference|perimeter|volume|surface area)\s+of\s+(?:a|an|the)?\s*(circle|sphere|triangle|rectangle|square|cylinder|cone)\s*([\s\S]*)/i);
  if (match) {
    const what = match[1].toLowerCase(), shape = match[2].toLowerCase(), rest = match[3];
    const nums = parseNumbers(rest);
    const labeled = key => { const m = rest.match(new RegExp(`${key}\\s*(?:=|of|is)?\\s*([\\d.]+)`, 'i')); return m ? Number(m[1]) : null; };
    const radius = labeled('radius') ?? labeled('r') ?? (/\bdiameter/.test(rest) ? (labeled('diameter') ?? nums[0]) / 2 : nums[0]);
    const height = labeled('height') ?? labeled('h') ?? nums[1];
    const base = labeled('base') ?? labeled('b') ?? nums[0];
    let answer = null, method = '';
    if (shape === 'circle' && radius) {
      if (what === 'area') { answer = Math.PI * radius ** 2; method = `A = πr² = π × ${fmt(radius)}²`; }
      else if (what === 'circumference') { answer = 2 * Math.PI * radius; method = `C = 2πr = 2 × π × ${fmt(radius)}`; }
    } else if (shape === 'sphere' && radius) {
      if (what === 'volume') { answer = (4 / 3) * Math.PI * radius ** 3; method = `V = (4/3)πr³`; }
      else if (what === 'surface area') { answer = 4 * Math.PI * radius ** 2; method = `A = 4πr²`; }
    } else if (shape === 'triangle' && base && height) {
      if (what === 'area') { answer = 0.5 * base * height; method = `A = ½bh = ½ × ${fmt(base)} × ${fmt(height)}`; }
    } else if ((shape === 'rectangle' || shape === 'square')) {
      const width = nums[0], len = nums[1] ?? nums[0];
      if (what === 'area') { answer = width * len; method = `A = lw = ${fmt(width)} × ${fmt(len)}`; }
      else if (what === 'perimeter') { answer = 2 * (width + len); method = `P = 2(l + w)`; }
    } else if (shape === 'cylinder' && radius && height) {
      if (what === 'volume') { answer = Math.PI * radius ** 2 * height; method = `V = πr²h`; }
      else if (what === 'surface area') { answer = 2 * Math.PI * radius * (radius + height); method = `A = 2πr(r + h)`; }
    } else if (shape === 'cone' && radius && height) {
      if (what === 'volume') { answer = (Math.PI * radius ** 2 * height) / 3; method = `V = ⅓πr²h`; }
    }
    if (answer !== null) {
      return { skill: 'geometry', text: `◆ ${titleCase(what)} of the ${shape}\n\n${fmt(answer)} ${/area|surface/.test(what) ? 'square units' : what === 'volume' ? 'cubic units' : 'units'}\n\n${method}. Substitute the numbers only after writing the formula, and keep the units consistent.`, followUps: ['Explain circles', 'Quiz me on geometry', 'What is Pythagoras?'] };
    }
  }
  match = text.match(/pythagoras|pythagorean/i) && text.match(/([\d.]+)\s*(?:and|,|\s)\s*([\d.]+)/);
  if (match) {
    const a = Number(match[1]), b = Number(match[2]);
    return { skill: 'geometry', text: `◆ Pythagoras\n\nHypotenuse: ${fmt(Math.hypot(a, b))}\n\nc = √(${a}² + ${b}²) = √(${fmt(a * a + b * b)}). This only applies to right triangles.`, followUps: ['Explain Pythagoras', 'Quiz me on geometry'] };
  }

  // finance
  match = text.match(/compound interest/i) && text.match(/([\d.]+)\s*(?:at|@)\s*([\d.]+)\s*%.*?(\d+)\s*(year|month)/i);
  if (match) {
    const principal = Number(match[1]), rate = Number(match[2]) / 100;
    const periods = Number(match[3]) * (/month/i.test(match[4]) ? 1 : 12);
    const perYear = /month/i.test(match[4]) ? 12 : 1;
    const amount = principal * (1 + rate / perYear) ** periods;
    return { skill: 'finance', text: `◆ Compound interest\n\nFinal amount: ${money(amount)}\nInterest earned: ${money(amount - principal)}\n\nA = P(1 + r/n)^(nt) with P = ${principal}, r = ${fmt(rate)}, n = ${perYear} per year, t = ${periods / perYear} years.`, followUps: ['Explain compound interest', 'Simple interest on 1000 at 5% for 3 years', 'Quiz me on finance'] };
  }
  match = text.match(/simple interest/i) && text.match(/([\d.]+)\s*(?:at|@)\s*([\d.]+)\s*%.*?([\d.]+)\s*(year|month)/i);
  if (match) {
    const principal = Number(match[1]), rate = Number(match[2]) / 100, years = Number(match[3]) / (/month/i.test(match[4]) ? 12 : 1);
    const interest = principal * rate * years;
    return { skill: 'finance', text: `◆ Simple interest\n\nInterest: ${money(interest)}\nTotal: ${money(principal + interest)}\n\nI = P·r·t = ${principal} × ${fmt(rate)} × ${fmt(years, 3)}. Simple interest ignores interest on interest.`, followUps: ['Explain compound interest', 'Compound interest 1000 at 5% for 10 years', 'Quiz me on finance'] };
  }

  // plain expression
  // plain expression (including operator words: "7 times 8", "square root of 144")
  const asSymbols = stripTrailingQuestion(q)
    .replace(/^(what is|what's|calculate|compute|evaluate|solve|how much is)\s+/i, '')
    .replace(/\bmultiplied by\b/gi, '*').replace(/\btimes\b/gi, '*')
    .replace(/\bplus\b/gi, '+').replace(/\bminus\b/gi, '-')
    .replace(/\bdivided by\b/gi, '/').replace(/\bover\b/gi, '/')
    .replace(/\bto the power of\b/gi, '^').replace(/\bsquared\b/gi, '^2').replace(/\bcubed\b/gi, '^3');
  const rootMatch = asSymbols.match(/^(?:square root of|root of)\s+([\d.]+)$/i);
  if (rootMatch) {
    const value = Number(rootMatch[1]);
    return { skill: 'math', text: `◆ √${fmt(value)}\n\n${fmt(Math.sqrt(value))}\n\nA square root asks which number squares to ${fmt(value)}. Check by squaring the answer.`, followUps: ['Explain exponents', 'Quiz me on arithmetic', 'What is 7 times 8?'] };
  }
  const wordResult = calculate(/^[\d.()+\-*/^%\s]+$/.test(asSymbols) ? `what is ${asSymbols}` : q);
  if (wordResult !== null) {
    return { skill: 'math', text: `◆ ${asSymbols || 'Calculation'}\n\n= ${wordResult}\n\nOrder of operations: brackets, powers, × and ÷, then + and −.`, followUps: ['Show the steps', 'Convert 12 km to miles', 'Quiz me on arithmetic'] };
  }
  if (result !== null) {
    const expressionOnly = q.replace(/(?:what is|what's|calculate|compute|evaluate|solve|how much is)/gi, '').trim();
    return { skill: 'math', text: `◆ ${stripTrailingQuestion(expressionOnly) || 'Calculation'}\n\n= ${result}\n\nWorked left to right inside each precedence level: brackets, powers, × and ÷, then + and −.`, followUps: ['Show the steps', 'Convert 12 km to miles', 'Quiz me on arithmetic'] };
  }
  return null;
}

function dateSkill(q) {
  const text = stripTrailingQuestion(q);

  let match = text.match(/days?\s+(?:until|till|to)\s+(.+)$/i);
  if (match) {
    const target = parseDate(match[1]);
    if (target) {
      const diff = dayDiff(new Date(), target);
      return { skill: 'date', text: `◆ ${diff >= 0 ? 'Days until' : 'Days since'} ${dateLabel(target)}\n\n${Math.abs(diff)} day${Math.abs(diff) === 1 ? '' : 's'}${diff >= 0 ? ' to go' : ' ago'}.\n\nToday is ${dateLabel(new Date())}. Counting whole calendar days avoids time-zone drift.`, followUps: ['Days between 2026-01-01 and 2026-12-25', 'What day is 2027-05-04?', 'Quiz me on dates'] };
    }
  }
  match = text.match(/days?\s+between\s+(.+?)\s+and\s+(.+)$/i);
  if (match) {
    const a = parseDate(match[1]), b = parseDate(match[2]);
    if (a && b) {
      return { skill: 'date', text: `◆ Days between\n\n${Math.abs(dayDiff(a, b))} days\n\n${dateLabel(a)} → ${dateLabel(b)}. That is about ${fmt(Math.abs(dayDiff(a, b)) / 7, 1)} weeks.`, followUps: ['Days until 2026-12-25', 'What day is 2027-05-04?'] };
    }
  }
  match = text.match(/(?:what|which)\s+day(?:\s+of\s+the\s+week)?\s+(?:is|was|will it be)?\s+(.+)$/i) || text.match(/^(.+)\s+(?:falls|lands)\s+on\s+what\s+day/i);
  if (match) {
    const target = parseDate(match[1]);
    if (target) return { skill: 'date', text: `◆ ${dateLabel(target)}\n\nThat date is a ${DAYS[target.getDay()]}.\n\nLeap years add a day every four years, except centuries not divisible by 400.`, followUps: ['Days until 2026-12-25', 'Days between 2026-01-01 and 2026-12-25'] };
  }
  match = text.match(/(?:what|which)\s+date\s+is\s+(-?\d+)\s+days?\s+(from|after|before)\s+today/i);
  if (match) {
    const offset = Number(match[1]) * (/before/i.test(match[2]) ? -1 : 1);
    const target = new Date();
    target.setDate(target.getDate() + offset);
    return { skill: 'date', text: `◆ ${offset >= 0 ? 'In' : 'Out'} ${Math.abs(offset)} days\n\n${dateLabel(target)} (${target.toISOString().slice(0, 10)})\n\nToday is ${dateLabel(new Date())}.`, followUps: ['Days until 2026-12-25', 'What day is 2027-05-04?'] };
  }
  return null;
}

function textSkill(q) {
  const quoted = q.match(/["“'']([\s\S]{2,600})["”'']/);
  const body = quoted ? quoted[1] : q.replace(/^.*?\b(?:in|of|this|text|sentence)\b[:\s]*/i, '');

  if (/\b(how many words|word count|count words|words in)\b/i.test(q)) {
    const words = body.trim().split(/\s+/).filter(Boolean);
    const unique = new Set(words.map(word => word.toLowerCase().replace(/[^a-z0-9]/g, '')).filter(Boolean));
    return { skill: 'text', text: `◆ Word count\n\n${words.length} words · ${body.length} characters · ${unique.size} unique words\n\nReading time at 220 words per minute: about ${fmt(Math.max(1, words.length / 220), 1)} minutes.`, followUps: ['Count characters in this text', 'Convert to title case', 'Explain readability'] };
  }
  if (/\b(how many characters|character count|count characters|characters in)\b/i.test(q)) {
    return { skill: 'text', text: `◆ Character count\n\n${body.length} characters including spaces · ${body.replace(/\s/g, '').length} without spaces · ${body.trim().split(/\s+/).filter(Boolean).length} words`, followUps: ['Count words in this text', 'Convert to uppercase'] };
  }
  if (/\b(uppercase|upper case|all caps)\b/i.test(q)) return { skill: 'text', text: `◆ Uppercase\n\n${body.toUpperCase()}`, followUps: ['Convert to lowercase', 'Convert to title case'] };
  if (/\b(lowercase|lower case)\b/i.test(q)) return { skill: 'text', text: `◆ Lowercase\n\n${body.toLowerCase()}`, followUps: ['Convert to uppercase', 'Convert to title case'] };
  if (/\b(title case|capitalize each word)\b/i.test(q)) return { skill: 'text', text: `◆ Title case\n\n${titleCase(body)}`, followUps: ['Convert to sentence case', 'Count words in this text'] };
  if (/\b(sentence case)\b/i.test(q)) {
    const cleaned = body.toLowerCase().replace(/(^\s*\w|[.!?]\s+\w)/g, letter => letter.toUpperCase());
    return { skill: 'text', text: `◆ Sentence case\n\n${cleaned}`, followUps: ['Convert to title case', 'Fix grammar'] };
  }
  if (/\b(reverse|backwards)\b/i.test(q) && /text|word|string|sentence|reverse\b/i.test(q)) {
    return { skill: 'text', text: `◆ Reversed\n\n${[...body].reverse().join('')}`, followUps: ['Is this a palindrome?', 'Count characters in this text'] };
  }
  if (/\bpalindrome\b/i.test(q)) {
    const cleaned = body.toLowerCase().replace(/[^a-z0-9]/g, '');
    const reversed = [...cleaned].reverse().join('');
    return { skill: 'text', text: `◆ Palindrome check\n\n${cleaned ? (cleaned === reversed ? 'Yes — it reads the same both ways.' : 'No — reversed it reads: ' + reversed.slice(0, 120)) : 'I need some text to check. Put it in quotes.'}`, followUps: ['Reverse this text', 'Count words in this text'] };
  }
  return null;
}

function phraseSkill(q) {
  const unsupported = q.match(/(?:translate|how do you say)\s+(.+?)\s+(?:in|into|to)\s+([a-z]+)(?:\?|$)/i);
  if (unsupported && !LANGUAGE_PACKS.includes(titleCase(unsupported[2]))) {
    return { skill: 'translate', text: `◆ Translation\n\nMy offline phrasebook covers ${LANGUAGE_PACKS.join(', ')} — not ${titleCase(unsupported[2])}, and I will not invent a translation.\n\nAsk for one of those languages, or use Chrome’s on-device model for a full translation.`, followUps: ['Translate hello to Spanish', 'Show the phrasebook', 'Open Text Lab'] };
  }
  const match = q.match(/(?:translate|how do you say|say)\s+(.+?)\s+(?:in|into|to)\s+(spanish|french|german|portuguese|japanese)/i);
  if (!match) return null;
  const phrase = match[1].replace(/^["“']|["”']$/g, '').replace(/^the phrase\s+/i, '').trim();
  const language = titleCase(match[2]);
  const key = phrase.toLowerCase().replace(/[^a-z ]/g, '').replace(/\s+/g, ' ').trim();
  const hit = PHRASES.find(row => row.en.toLowerCase().replace(/[^a-z ]/g, '') === key) || PHRASES.find(row => row.en.toLowerCase().includes(key) && key.length > 3);
  if (hit) {
    return { skill: 'translate', text: `◆ “${hit.en}” in ${language}\n\n${hit[language]}\n\nOffline phrasebook entry — pronunciation and register vary by region, so a native speaker or the local model is a better final check.`, followUps: [`How do you say thank you in ${language}?`, 'Show the phrasebook', 'Explain tone in translation'] };
  }
  const samples = PHRASES.slice(0, 4).map(row => `• ${row.en} → ${row[language]}`).join('\n');
  return { skill: 'translate', text: `◆ Phrasebook: ${language}\n\nI could not find “${phrase}” in the offline phrasebook (${PHRASES.length} everyday phrases), so I will not guess a translation.\n\nA few entries I do have:\n${samples}\n\nFor a full translation, the on-device Chrome model is needed.`, followUps: ['Show the phrasebook', 'Translate hello to Spanish', 'Open Text Lab'] };
}

function codeSkill(q) {
  const norm = normalize(q);
  const hit = CODE_HELP.find(entry => entry.keys.some(key => norm.includes(normalize(key))));
  if (hit) {
    return { skill: 'code', text: `◆ ${titleCase(hit.keys[0])}\n\n${hit.text}`, followUps: ['Explain big O', 'Show git undo commands', 'Debug this error'] };
  }
  const glossary = GLOSSARY.find(item => norm.split(' ').includes(normalize(item.term)));
  if (glossary && /\b(what is|define|meaning|explain|how does)\b/i.test(q)) {
    return { skill: 'glossary', text: `◆ ${titleCase(glossary.term)}\n\n${glossary.def}`, followUps: [`Teach me more about ${glossary.term}`, 'Quiz me on this', 'Show related topics'] };
  }
  return null;
}

function quizSkill(q, history = []) {
  if (!/\b(quiz|test me|practice questions?|questions about|flashcards?|exam)\b/i.test(q)) return null;
  let topic = q.replace(/.*\b(?:on|about|for)\b/i, '').replace(/\b(quiz me|quiz|test me|practice questions?|flashcards?|make|create|give me|some|a|an|the|5|five|10|ten|questions?)\b/gi, ' ').trim();
  if (!topic || /^(this|that|it|these|those|the last one)$/i.test(topic)) {
    const previous = [...history].reverse().find(turn => turn.role === 'assistant' && /◆/.test(turn.content || ''));
    topic = (previous?.content.match(/◆\s*([^\n]+)/)?.[1] || '').replace(/\s+—.*$/, '').trim();
  }
  const lessons = searchKnowledge(topic || q, 3);
  const asked = q.match(/\b(\d{1,2})\s+(?:questions|cards)\b/i);
  const wantCards = /flashcard/i.test(q);
  if (!lessons.length) {
    return { skill: 'quiz', text: `◆ Quiz\n\nI do not have offline notes for “${topic || q}”, so I will not invent quiz content.\n\nTry a subject from the library — for example biology, fractions, chemistry, history, grammar, statistics or programming — or open Learn Lab for a generated deck.`, followUps: ['Quiz me on biology', 'Quiz me on fractions', 'Open Learn Lab'] };
  }
  if (wantCards) {
    const cards = [];
    lessons.forEach(lesson => {
      const firstSentence = lesson.text.split(/(?<=[.!?])\s+/)[0];
      cards.push(`Q: ${lesson.title}?\nA: ${firstSentence}`);
    });
    return { skill: 'quiz', text: `◆ Flashcards\n\n${cards.join('\n\n')}\n\nCover the answer, say it aloud, then check. Spacing beats rereading.`, followUps: ['Quiz me on this', 'Make a study plan', 'Open Learn Lab'] };
  }
  const count = Math.min(5, Math.max(1, Number(asked?.[1] || 3)));
  const pool = lessonPool();
  const questions = [];
  for (let i = 0; i < count; i += 1) {
    const lesson = lessons[i % lessons.length];
    const others = pool.filter(item => item.title !== lesson.title).sort(() => Math.random() - 0.5).slice(0, 3);
    const options = [lesson.title, ...others.map(item => item.title)].sort(() => Math.random() - 0.5);
    questions.push({ prompt: `Which note matches: “${lesson.text.split(/(?<=[.!?])\s+/)[0].slice(0, 130)}”`, options, answer: lesson.title });
  }
  const body = questions.map((question, index) => `${index + 1}. ${question.prompt}\n${question.options.map((option, i) => `   ${'ABCD'[i]}. ${option}`).join('\n')}`).join('\n\n');
  const answers = questions.map((question, index) => `${index + 1}. ${'ABCD'[question.options.indexOf(question.answer)]} — ${question.answer}`).join('\n');
  return { skill: 'quiz', text: `◆ Quiz · ${lessons.length} topics\n\n${body}\n\nAnswers\n${answers}\n\nOpen Learn Lab for scored quizzes, streaks and XP.`, followUps: ['Quiz me on chemistry', 'Explain the first one', 'Open Learn Lab'] };
}

function studyPlanSkill(q) {
  const match = q.match(/study plan.*?(?:for|about|on)\s+(.+?)(?:\s+in\s+(\d+)\s+days?)?$/i);
  if (!/study plan|revise for|prepare for/i.test(q)) return null;
  const topic = match?.[1]?.replace(/\b(exam|test)\b/gi, '').trim() || 'your topic';
  const days = Math.min(21, Math.max(1, Number(match?.[2] || 5)));
  const lessons = searchKnowledge(topic, 4);
  const chunks = [];
  for (let day = 1; day <= days; day += 1) {
    const lesson = lessons[(day - 1) % Math.max(1, lessons.length)];
    if (day === days) chunks.push(`Day ${day} · light review + sleep early. Re-test the two ideas you got wrong, then stop.`);
    else if (day === Math.max(1, days - 1)) chunks.push(`Day ${day} · full practice under timed conditions${lesson ? ` on ${lesson.title}` : ''}. Mark it honestly.`);
    else if (day % 3 === 0 || !lesson) chunks.push(`Day ${day} · recall day: close the notes, write what you remember, then check gaps.`);
    else chunks.push(`Day ${day} · ${lesson.title}: read once, then explain it aloud without notes.`);
  }
  return { skill: 'plan', text: `◆ ${days}-day plan · ${topic}\n\n${chunks.join('\n')}\n\nRules that matter more than the schedule: retrieve before rereading, space sessions, and sleep after study. Miss a day? Resume — do not restart.`, followUps: ['Quiz me on this', 'Make flashcards', 'Open Learn Lab'] };
}

function funSkill(q) {
  if (/\bjoke|make me laugh|pun\b/i.test(q)) return { skill: 'fun', text: `◆ Joke\n\n${JOKES[Math.floor(Math.random() * JOKES.length)]}\n\nWant another? Ask for a joke.`, followUps: ['Tell me another joke', 'Give me a fun fact', 'Quiz me'] };
  if (/\bfun fact|random fact|did you know\b/i.test(q)) return { skill: 'fun', text: `◆ Fun fact\n\n${FUN_FACTS[Math.floor(Math.random() * FUN_FACTS.length)]}`, followUps: ['Another fun fact', 'Teach me something new', 'Quiz me'] };
  if (/\bflip a coin|coin flip|heads or tails\b/i.test(q)) return { skill: 'fun', text: `◆ Coin flip\n\n${Math.random() < 0.5 ? 'Heads' : 'Tails'}`, followUps: ['Roll a die', 'Pick a number between 1 and 10'] };
  if (/\broll (?:a|the|one)? ?d(?:ie|ice)\b|\broll a die\b/i.test(q)) return { skill: 'fun', text: `◆ Die roll\n\n🎲 ${1 + Math.floor(Math.random() * 6)}`, followUps: ['Flip a coin', 'Pick a number between 1 and 10'] };
  const pick = q.match(/pick one[:\s]+(.+)$/i) || q.match(/choose between\s+(.+)$/i);
  if (pick) {
    const options = pick[1].split(/,|\bor\b/).map(item => item.trim()).filter(Boolean);
    if (options.length > 1) return { skill: 'fun', text: `◆ My pick\n\n${options[Math.floor(Math.random() * options.length)]}\n\nRandom choice is honest, not advice — you know the context I do not.`, followUps: ['Flip a coin', 'Give me a fun fact'] };
  }
  const range = q.match(/random number(?: between)?\s*(-?\d+)\s*(?:and|to|-)\s*(-?\d+)/i);
  if (range) {
    const low = Math.min(Number(range[1]), Number(range[2])), high = Math.max(Number(range[1]), Number(range[2]));
    return { skill: 'fun', text: `◆ Random number\n\n${low + Math.floor(Math.random() * (high - low + 1))}`, followUps: ['Roll a die', 'Flip a coin'] };
  }
  if (/\bmagic 8|yes or no\b/i.test(q)) {
    const answers = ['Yes.', 'No.', 'Ask again after you check one fact.', 'Probably — but verify it.', 'Not yet.', 'Yes, and write down why.'];
    return { skill: 'fun', text: `◆ ${answers[Math.floor(Math.random() * answers.length)]}\n\n(Nova’s eight-ball is a coin with opinions — useful for unblocking, not for decisions.)`, followUps: ['Flip a coin', 'Give me a fun fact'] };
  }
  return null;
}

function pageSkill(q, prompt) {
  const hasPage = /\[End page context\]/i.test(String(prompt || ''));
  if (!hasPage) {
    if (/summari[sz]e (this|the) (page|tab|article)|page summary|tldr of (this|the) page|key points of this page/i.test(q)) {
      return { skill: 'page', text: `◆ Page summary\n\nI do not have this page yet — Nova reads a page only when you ask.\n\nTurn on the ▣ page toggle in the composer (or open Page Research) and ask again. Your page is never sent anywhere; it is read in this extension.`, followUps: ['Open Page Research', 'What can you do?', 'Quiz me on reading comprehension'] };
    }
    return null;
  }
  const offline = answerOffline(prompt);
  if (/offline reference mode/i.test(offline)) return null;
  return { skill: 'page', text: `◆ From your page\n\n${offline}`, followUps: ['Explain simpler', 'Summarise more briefly', 'Quiz me on this'] };
}

function lessonSkill(q, persona) {
  const [best, second, third] = searchKnowledge(q, 3);
  if (!best) return null;
  const sentences = best.text.split(/(?<=[.!?])\s+/);
  const related = [second, third].filter(Boolean);
  const opener = { tutor: 'Let us build this up.', coach: 'Short version first.', coder: 'Concept, then the practical bit.', editor: 'Here is the clean version.', socratic: 'Before the answer, one question.', buddy: 'Got it — here is the friendly version.' }[persona.id] || '';
  const socraticQuestions = [
    `What do you already know about “${best.title.split(':').pop().trim()}”?`,
    `Where would you expect to use this?`,
    'Which part feels least clear right now?'
  ];
  let body = `◆ ${best.title}\n\n${persona.id === 'socratic' ? `${opener}\n${bullet(socraticQuestions)}\n\nNow the short version:\n` : `${opener}\n`}${best.text}`;
  if (persona.id === 'coach') body = `◆ ${best.title}\n\n${opener}\n${bullet(sentences.slice(0, 3).map(sentence => sentence.trim()))}\n\nNext action: explain it aloud in three sentences, then test yourself.`;
  if (persona.id === 'editor') body = `◆ ${best.title}\n\n${best.text}\n\nIn one line: ${sentences[0]}`;
  if (persona.id === 'coder' && /code|algorithm|sql|regex|git|http|binary/i.test(best.tags.join(' '))) body = `◆ ${best.title}\n\n${best.text}\n\nPractical next step: open Learn Lab and quiz yourself on this before you ship code that relies on it.`;
  if (related.length) body += `\n\nRelated notes\n${bullet(related.map(lesson => lesson.title))}`;
  body += `\n\nTry this\n${bullet(['Explain it back in your own words — that is the real test.', 'Ask for an example and a worked step.', 'Ask “quiz me on this” to check recall.'])}`;
  return {
    skill: 'lesson',
    text: body,
    followUps: ['Explain simpler', 'Give me an example', 'Quiz me on this', related[0] ? `Teach me ${related[0].title.split(':').pop().trim()}` : 'What can you do?']
  };
}

function followUpIntent(q) {
  const text = normalize(q);
  if (text.split(' ').filter(Boolean).length > 7) return null;
  if (/\b(simpler|simple|eli5|plain english)\b/.test(text)) return 'simpler';
  if (/\b(example|examples|demonstrate|worked example)\b/.test(text)) return 'example';
  if (/(^|\s)why(\s|$)/.test(text)) return 'why';
  if (/\b(more|deeper|detail|details|continue|another|again|go on)\b/.test(text)) return 'more';
  return null;
}
function followUpSkill(q, history, persona) {
  if (!followUpIntent(q)) return null;
  const last = [...(history || [])].reverse().find(turn => turn.role === 'assistant' && /◆/.test(turn.content || ''));
  if (!last) return null;
  const title = (last.content.match(/◆\s*([^\n]+)/) || [])[1]?.trim();
  const lesson = title ? lessonPool().find(item => item.title.toLowerCase() === title.toLowerCase()) : null;
  if (!lesson) return null;
  const first = lesson.text.split(/(?<=[.!?])\s+/)[0];
  const lastSentence = lesson.text.split(/(?<=[.!?])\s+/).at(-1);
  if (/simpler|simple|eli5/i.test(q)) {
    return { skill: 'followup', text: `◆ ${lesson.title} — simple version\n\n${first}\n\nPicture it this way: start with the smallest example you can write down, change one thing at a time, and watch what happens. That is the whole idea without the vocabulary.`, followUps: ['Give me an example', 'Quiz me on this', 'Explain more deeply'] };
  }
  if (/example/i.test(q)) {
    const example = (lesson.text.match(/(?:Example|For example|e\.g\.)[^.]*\.[^.]*\./) || [])[0];
    return { skill: 'followup', text: `◆ ${lesson.title} — worked example\n\n${example || `Take the simplest case from the note: ${first}\n\nNow change one value and predict the result before you compute it. Predicting is what turns reading into learning.`}`, followUps: ['Explain simpler', 'Quiz me on this', 'Practice problems'] };
  }
  if (/why/i.test(q)) {
    return { skill: 'followup', text: `◆ Why this matters\n\n${lastSentence}\n\nReasoning behind the note: ${first}\n\nIf the “why” is still unclear, ask for a counter-example — the boundary of a rule is where understanding usually starts.`, followUps: ['Give me an example', 'Explain simpler', 'Quiz me on this'] };
  }
  return { skill: 'followup', text: `◆ ${lesson.title} — deeper\n\n${lesson.text}\n\nBoundary: this note is a curated summary, not a full textbook chapter. Name the specific part you want pushed further and I will go at it from another angle.`, followUps: ['Explain simpler', 'Give me an example', 'Quiz me on this'] };
}

function metaSkill(q) {
  const norm = normalize(q);
  if (/^(hi|hello|hey|yo|good morning|good afternoon|good evening|how are you)\b/.test(norm)) {
    const hour = new Date().getHours();
    const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
    return { skill: 'meta', text: `◆ ${greeting}\n\nI am Nova — a local-first browser sidekick. I can teach ${lessonPool().length} curated topics, do calculations and conversions, quiz you, rewrite text, and read the page you are on.\n\nWhat are we working on?`, followUps: ['Quiz me on biology', 'What can you do?', 'Tell me a fun fact'] };
  }
  if (/\b(who are you|what are you|your name|are you chatgpt|are you an ai|which model)\b/i.test(q)) {
    return { skill: 'meta', text: `◆ I am Nova\n\nA browser extension with a local reasoning engine and a curated reference library. No API keys, no hosted model, no account — what I answer runs on this device.\n\nHonest limits: I am not a trained large model. I compute, convert, look up ${lessonPool().length} curated notes and ${GLOSSARY.length} glossary terms, and I will say “I do not know” instead of inventing an answer. When Chrome exposes its on-device model, open-ended questions get that instead.`, followUps: ['What can you do?', 'How do you work?', 'Show me a fun fact'] };
  }
  if (/\b(what can you do|help|commands|capabilities|features)\b/i.test(q)) {
    return { skill: 'meta', text: `◆ What Nova can do\n\n${bullet([
      'Teach — ' + lessonPool().length + ' curated notes across maths, science, coding, writing, history, economics, health and the arts',
      'Compute — arithmetic, percentages, discounts, ratios, statistics, geometry, interest',
      'Convert — length, mass, volume, data sizes, speed, time and temperature',
      'Dates — days between, days until, what weekday a date falls on',
      'Text Lab — counts, case changes, reverse, palindrome checks',
      'Learn Lab — scored quizzes, flashcards, XP, streaks and a daily challenge',
      'Page work — summaries, selection tools, transcript notes, page styling',
      'Code help — big-O, git, JavaScript, Python, CSS, SQL, regex',
      'Translate — a 40-phrase offline phrasebook in five languages'
    ])}\n\nPress Ctrl+K (⌘K on a Mac) for the command palette.`, followUps: ['Open Learn Lab', 'Open Text Lab', 'Quiz me on something'] };
  }
  if (/\b(how do you work|are you trained|do you learn|your brain)\b/i.test(q)) {
    return { skill: 'meta', text: `◆ Under the hood\n\nA rules engine plus a curated library. Each question is routed by pattern: arithmetic gets a real parser, conversions use exact factors, lessons are matched by tag and keyword scoring, quizzes are generated from the notes you actually asked about.\n\nWhat it is not: a neural network that learned from the internet. That honesty is the feature — every answer is inspectable, and it never fabricates a citation.`, followUps: ['What can you do?', 'Quiz me on how you work', 'Give me a fun fact'] };
  }
  if (/^(thank you|thanks|ty|cheers)[\s!.]*$/i.test(norm)) {
    return { skill: 'meta', text: `◆ Anytime\n\nWant to lock it in? Ask “quiz me on this” — recall now saves you a reread later.`, followUps: ['Quiz me on this', 'Give me a fun fact', 'Start a new chat'] };
  }
  return null;
}

/* -------------------------------- composer -------------------------------- */

function suggestTopics(q) {
  const words = normalize(q).split(' ').filter(word => word.length > 3);
  const pool = lessonPool();
  const scored = pool.map(lesson => {
    const haystack = normalize(`${lesson.title} ${lesson.tags.join(' ')} ${lesson.text}`);
    const score = words.reduce((sum, word) => sum + (haystack.includes(word) ? 1 : 0), 0);
    return { lesson, score };
  }).filter(item => item.score > 0).sort((a, b) => b.score - a.score).slice(0, 4);
  return scored.map(item => item.lesson.title);
}

function fallbackSkill(q, persona) {
  const topics = suggestTopics(q);
  const related = topics.length ? `\n\nClosest notes I do have\n${bullet(topics)}` : '';
  const sampleQuiz = Math.random() < 0.5 ? 'Quiz me on biology' : 'Give me a fun fact';
  const personaLine = persona.id === 'socratic' ? '\n\nTry this: say the question in one sentence without jargon, then name exactly what is missing.' : '\n\nA good next move: narrow the question to one topic and one goal (“explain X like I am new”, “compare X and Y”, “check my calculation”).';
  return {
    skill: 'fallback',
    text: `◆ I would rather not guess\n\nI have no confident offline match for that, and Nova has no hosted model to fall back on.${related}${personaLine}\n\nAsk about anything in the library, or use Learn Lab to explore ${lessonPool().length} topics.`,
    followUps: [sampleQuiz, 'What can you do?', 'Open Learn Lab']
  };
}

export function brainReply(prompt, options = {}) {
  const persona = getPersona(options.persona);
  const history = options.history || [];
  const q = cleanQuestion(prompt);
  if (!q) return { text: '◆ Ready\n\nAsk me something — arithmetic, conversions, a concept, a quiz, or a page summary.', followUps: ['What can you do?', 'Quiz me on biology'], skill: 'empty' };

  const chain = [
    () => metaSkill(q),
    () => followUpSkill(q, history, persona),
    () => mathSkill(q),
    () => dateSkill(q),
    () => studyPlanSkill(q),
    () => quizSkill(q, history),
    () => phraseSkill(q),
    () => codeSkill(q),
    () => textSkill(q),
    () => funSkill(q),
    () => pageSkill(q, prompt),
    () => lessonSkill(q, persona),
    () => {
      const offline = answerOffline(prompt);
      if (/offline reference mode/.test(offline)) return null;
      return { skill: 'offline', text: `◆ From your page\n\n${offline}`, followUps: ['Explain simpler', 'Summarise more briefly', 'Quiz me on this'] };
    }
  ];
  for (const step of chain) {
    try {
      const result = step();
      if (result) return { ...result, persona: persona.id };
    } catch { /* a failed skill must never break the chat */ }
  }
  return { ...fallbackSkill(q, persona), persona: persona.id };
}

export function brainStats() {
  return {
    lessons: lessonPool().length,
    glossary: GLOSSARY.length,
    phrases: PHRASES.length,
    personas: PERSONAS.length,
    skills: ['math', 'percent', 'convert', 'ratio', 'statistics', 'number', 'geometry', 'finance', 'date', 'text', 'translate', 'code', 'glossary', 'quiz', 'plan', 'fun', 'lesson', 'followup', 'meta']
  };
}

export function samplePhrase(language) {
  return PHRASES.slice(0, 7).map(row => ({ en: row.en, text: row[language] || '' }));
}
