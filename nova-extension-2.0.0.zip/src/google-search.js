(() => {
  const HOST_ID='nova-search-summary-widget';let activeKey='',dismissedKey='',observer,timer;
  const clean=value=>String(value||'').replace(/\s+/g,' ').trim();
  function extractVisibleResults(){
    const query=clean(document.querySelector('textarea[name="q"]')?.value||new URL(location.href).searchParams.get('q')).slice(0,300);
    const root=document.querySelector('#rso')||document.querySelector('main');if(!root)return{query,results:[]};
    const seen=new Set(),results=[];
    for(const container of root.querySelectorAll('div.MjjYud,div.g')){
      const heading=container.querySelector('h3'),anchor=heading?.closest('a');if(!heading||!anchor?.href||seen.has(anchor.href))continue;
      const rect=container.getBoundingClientRect();if(rect.width<=0||rect.height<=0)continue;seen.add(anchor.href);
      const snippet=clean(container.querySelector('.VwiC3b,[data-sncf],[class*="snippet"]')?.innerText||container.innerText).slice(0,500);
      results.push({title:clean(heading.innerText).slice(0,180),url:anchor.href.slice(0,500),snippet});if(results.length===8)break;
    }return{query,results};
  }
  function ensureWidget(){
    let host=document.getElementById(HOST_ID);if(host)return host;
    host=document.createElement('section');host.id=HOST_ID;host.setAttribute('aria-label','Nova quick view of visible Google results');
    const shadow=host.attachShadow({mode:'open'}),style=document.createElement('style');
    style.textContent=':host{display:block;margin:12px 0 16px;font:13px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;color:#252438;animation:rise .32s ease-out}@keyframes rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}.card{border:1px solid #e5e0f5;border-radius:14px;background:linear-gradient(135deg,#fff,#faf8ff);box-shadow:0 5px 18px #3c306612;padding:14px 16px}.head{display:flex;align-items:center;gap:8px;color:#6a55cf;font-weight:800}.mark{display:grid;place-items:center;width:22px;height:22px;border-radius:8px;background:#f0edff}.label{flex:1}.state{font-size:11px;color:#8a8798;font-weight:600}.body{margin-top:10px;color:#4b485c;white-space:pre-wrap;overflow-wrap:anywhere}.foot{margin-top:9px;color:#8e8b9d;font-size:10px}.head button{border:0;background:transparent;color:#858196;cursor:pointer;font-size:18px}';
    const card=document.createElement('div');card.className='card';const head=document.createElement('div');head.className='head';const mark=document.createElement('span');mark.className='mark';mark.textContent='✦';const label=document.createElement('span');label.className='label';label.textContent='Nova · Search quick view';const state=document.createElement('span');state.className='state';state.textContent='Local extract';const close=document.createElement('button');close.type='button';close.setAttribute('aria-label','Close Nova quick view');close.textContent='×';close.addEventListener('click',()=>{dismissedKey=activeKey;host.remove();});head.append(mark,label,state,close);const body=document.createElement('div');body.className='body';const foot=document.createElement('div');foot.className='foot';foot.textContent='Extractive list of result snippets already visible on this page. No AI summary, search API, or network request.';card.append(head,body,foot);shadow.append(style,card);const root=document.querySelector('#rso')||document.querySelector('main');if(root?.parentNode)root.parentNode.insertBefore(host,root);else document.body?.prepend(host);return host;
  }
  async function summarize(){
    const{query,results}=extractVisibleResults(),key=`${location.href}|${query}|${results.map(x=>x.title).join('|')}`;
    if(!query||!results.length||key===activeKey||key===dismissedKey)return;activeKey=key;
    const{novaAutoGoogleSummary=true}=await chrome.storage.local.get('novaAutoGoogleSummary').catch(()=>({}));if(!novaAutoGoogleSummary)return;
    const host=ensureWidget(),shadow=host.shadowRoot;shadow.querySelector('.body').textContent=`Query: ${query}\n\n${results.slice(0,5).map((item,index)=>`${index+1}. ${item.title}\n${item.snippet||item.url}`).join('\n\n')}\n\nThis is an extractive quick view of snippets, not an AI-generated synthesis.`;
  }
  function schedule(){clearTimeout(timer);timer=setTimeout(summarize,650);}schedule();observer=new MutationObserver(()=>{if(!document.getElementById(HOST_ID)&&document.querySelector('#rso'))activeKey='';schedule();});observer.observe(document.documentElement,{childList:true,subtree:true});window.addEventListener('popstate',()=>{activeKey='';schedule();});chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local'||!changes.novaAutoGoogleSummary)return;if(changes.novaAutoGoogleSummary.newValue===false)document.getElementById(HOST_ID)?.remove();else{activeKey='';dismissedKey='';schedule();}});
})();
