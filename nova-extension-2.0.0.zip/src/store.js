// Tiny storage adapter: chrome.storage.local in the extension, localStorage when the
// panel is previewed as a plain page. Never throws; a failed read returns the fallback.
const chromeStore = typeof chrome !== 'undefined' && chrome?.storage?.local;

export const store = {
  async get(key, fallback = null) {
    try {
      if (chromeStore) {
        const result = await chrome.storage.local.get(key);
        return result?.[key] ?? fallback;
      }
      const raw = localStorage.getItem(key);
      return raw === null ? fallback : JSON.parse(raw);
    } catch { return fallback; }
  },
  async set(key, value) {
    try {
      if (chromeStore) await chrome.storage.local.set({ [key]: value });
      else localStorage.setItem(key, JSON.stringify(value));
    } catch { /* storage unavailable: feature stays in memory */ }
  }
};
