const STEPS=[
  {title:'Meet Nova Chat',text:'Ask questions in the chat dock. Chrome’s on-device model may answer; if it is unavailable, Nova falls back to its clearly limited offline reference—not a hosted model.',view:'chat'},
  {title:'Nova Hand',text:'Hand can inspect the current page and propose a short browser plan. Review each action. Higher-impact actions are blocked.',view:'hand'},
  {title:'Nova Code',text:'Describe a visual page change, review CSS, preview it, and undo it. This styles the rendered page; it does not modify the website’s source files.',view:'code'},
  {title:'Nova Create',text:'Compose downloadable SVG graphics and animated SVG scenes locally. They are procedural vector designs, not AI-generated images or MP4 videos.',view:'studio'},
  {title:'Page tools and privacy',text:'Summaries, selection tools, transcript reading, and file analysis use content only when you request it. Nova has no API keys, hosted provider, companion bridge, or remote service.',view:'chat'}
];
export function initTutorial(setView){
  const $=id=>document.getElementById(id);let index=0;
  function render(){const step=STEPS[index];$('tutorialTitle').textContent=step.title;$('tutorialStep').textContent=step.text;$('tutorialProgress').style.width=`${(index+1)/STEPS.length*100}%`;$('tutorialPrev').disabled=index===0;$('tutorialNext').textContent=index===STEPS.length-1?'Finish':'Next';setView(step.view);}
  function open(){index=0;$('tutorialCard').classList.remove('hidden');render();$('tutorialNext').focus();}
  function close(){ $('tutorialCard').classList.add('hidden');chrome.storage.local.set({novaTutorialSeen:true});$('tutorialButton').focus();}
  $('tutorialButton').addEventListener('click',open);$('tutorialFromSettings').addEventListener('click',open);$('closeTutorial').addEventListener('click',close);
  $('tutorialPrev').addEventListener('click',()=>{if(index>0){index--;render();}});
  $('tutorialNext').addEventListener('click',()=>{if(index<STEPS.length-1){index++;render();}else close();});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('tutorialCard').classList.contains('hidden'))close();});
  return {open,close};
}
