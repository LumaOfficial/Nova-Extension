chrome.runtime.onInstalled.addListener(async () => {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  const settings = await chrome.storage.local.get(['novaAutoGoogleSummary', 'novaTutorialSeen']);
  const updates = {};
  if (settings.novaAutoGoogleSummary === undefined) updates.novaAutoGoogleSummary = true;
  if (settings.novaTutorialSeen === undefined) updates.novaTutorialSeen = false;
  if (Object.keys(updates).length) await chrome.storage.local.set(updates);
});
