const LESSONS = [
  { tags:['calculus','derivative','differentiation','rate of change','chain rule'], title:'Calculus: derivatives', text:'A derivative measures an instantaneous rate of change. Geometrically, it is the slope of the tangent line. For f(x)=xⁿ, the power rule gives f′(x)=n·xⁿ⁻¹. The chain rule handles a function inside another: if y=f(g(x)), then y′=f′(g(x))·g′(x). Example: d/dx (3x+1)² = 2(3x+1)·3 = 18x+6. Check by expanding to 9x²+6x+1 and differentiating.' },
  { tags:['integral','integration','antiderivative','area under'], title:'Calculus: integrals', text:'An integral accumulates quantities. A definite integral ∫ₐᵇ f(x)dx is signed area and the limit of sums of thin rectangles. An antiderivative F satisfies F′=f. The Fundamental Theorem of Calculus says ∫ₐᵇ f(x)dx=F(b)−F(a), when the functions meet its conditions. Example: ∫₀² 3x² dx = [x³]₀² = 8.' },
  { tags:['limit','continuity','epsilon','infinity'], title:'Calculus: limits and continuity', text:'A limit describes the value f(x) approaches as x approaches a, even if f(a) differs or is undefined. A function is continuous at a when f(a) exists, limₓ→ₐ f(x) exists, and those values are equal. For a polynomial, direct substitution evaluates the limit. For 0/0 forms, factor or rationalize before substituting; 0/0 is indeterminate, not an answer.' },
  { tags:['linear algebra','matrix','vector','eigenvalue','eigenvector','basis','span'], title:'Linear algebra foundations', text:'A vector is an ordered list of numbers; vectors can represent positions, directions, or data. A matrix represents a linear transformation. A basis is a linearly independent set that spans a vector space. Solving Ax=b asks for a vector x that the transformation A maps to b. An eigenvector v satisfies Av=λv: its direction is preserved by A, and λ is the scale factor. Check dimensions before multiplying matrices.' },
  { tags:['probability','conditional probability','bayes','independence'], title:'Probability and Bayes’ rule', text:'Probability measures uncertainty from 0 to 1. The complement rule is P(not A)=1−P(A). Conditional probability is P(A|B)=P(A∩B)/P(B), provided P(B)>0. Bayes’ rule reverses conditioning: P(A|B)=P(B|A)P(A)/P(B). Independence means P(A∩B)=P(A)P(B); it is stronger than merely being uncorrelated in general.' },
  { tags:['statistics','mean','median','standard deviation','sampling','confidence interval'], title:'Statistics: summaries and uncertainty', text:'The mean is the arithmetic average and is sensitive to outliers; the median is the middle ordered value and is more resistant. Standard deviation describes typical spread around the mean. A confidence interval is produced by a procedure that, under its assumptions, covers the true parameter at the stated long-run rate; it is not a probability statement about a fixed parameter after the interval is observed. Random sampling and sample size matter.' },
  { tags:['mechanics','newton','force','acceleration','physics','free body diagram'], title:'Mechanics: Newton’s laws', text:'Newton’s second law is ΣF=ma: net force equals mass times acceleration. Draw a free-body diagram with only forces acting on the chosen object, choose axes, resolve components, then apply the law along each axis. Weight near Earth is mg downward; a normal force is a contact force perpendicular to a surface. Newton’s third-law force pairs act on different objects, so they do not cancel on one object’s diagram.' },
  { tags:['energy','physics work','kinetic','potential','conservation'], title:'Physics: work and energy', text:'Work by a constant force is W=F·d·cosθ. Kinetic energy is K=½mv². Near Earth, gravitational potential energy is U=mgh relative to a chosen reference height. The work-energy theorem says net work changes kinetic energy: Wnet=ΔK. When only conservative forces do work, mechanical energy K+U is conserved. Track units and signs; friction usually converts mechanical energy into thermal energy.' },
  { tags:['electricity','voltage','current','resistance','ohm','circuit'], title:'Electric circuits: Ohm’s law', text:'Current I is charge flow per time, voltage V is energy per charge, and resistance R relates them through V=IR for an ohmic component at fixed conditions. Electrical power is P=IV, also I²R or V²/R when Ohm’s law applies. In series, current is shared and resistances add. In parallel, voltage is shared and reciprocal resistances add: 1/Rₑq=Σ(1/Rᵢ). Real components may be nonlinear.' },
  { tags:['chemistry','mole','moles','molarity','stoichiometry','limiting reagent','avogadro','avogadro number','molar mass'], title:'Chemistry: moles and stoichiometry', text:'A mole is 6.02214076×10²³ specified entities. Molar mass converts mass to amount: n=m/M. Balance a chemical equation first to obtain mole ratios, convert given quantities to moles, use the coefficient ratio, then convert to the requested units. Molarity is concentration c=n/V with volume in litres. The limiting reagent is the reactant that runs out first and determines the maximum product.' },
  { tags:['atom','periodic table','electron','bond','ionic','covalent'], title:'Chemistry: atoms and bonding', text:'Atoms contain protons and neutrons in a nucleus and electrons around it. Atomic number counts protons; isotopes differ in neutron number. Ionic bonding involves electrostatic attraction between ions after electron transfer; covalent bonding involves shared electron density. The periodic table groups elements with related valence-electron patterns, but trends have exceptions. Lewis structures help track valence electrons and bonding, though they are models rather than literal pictures.' },
  { tags:['biology','cell','mitochondria','mitochondrion','organelles','membrane'], title:'Biology: cells and membranes', text:'Cells are the basic units of life. The plasma membrane is a selectively permeable phospholipid bilayer with proteins. Diffusion moves particles down a concentration gradient; osmosis is water movement across a selectively permeable membrane. Mitochondria perform much cellular respiration in eukaryotes; ribosomes build proteins; the nucleus houses most eukaryotic DNA. Organelles cooperate as a system.' },
  { tags:['photosynthesis','cellular respiration','chloroplast','glucose'], title:'Biology: photosynthesis and respiration', text:'Photosynthesis captures light energy to build energy-rich molecules. A simplified equation is 6CO₂+6H₂O+light → C₆H₁₂O₆+6O₂. Cellular respiration transfers energy from molecules such as glucose to ATP; a simplified net equation is C₆H₁₂O₆+6O₂ → 6CO₂+6H₂O+usable energy. The equations are related but the processes use different pathways and are regulated separately.' },
  { tags:['dna','gene','genetics','transcription','translation','protein'], title:'Biology: genes and gene expression', text:'DNA stores hereditary information in sequences of nucleotide bases. A gene is a DNA region that contributes to a functional product. In the central-dogma shorthand, transcription makes RNA from a DNA template and translation uses messenger RNA to assemble a polypeptide at a ribosome. Regulation controls when and how strongly genes are expressed. Mutations can be harmful, neutral, or beneficial depending on context.' },
  { tags:['evolution','natural selection','adaptation','allele','fitness'], title:'Biology: evolution by natural selection', text:'Evolution is change in heritable characteristics of populations across generations. Natural selection occurs when heritable variation affects survival or reproduction in a particular environment, changing variant frequencies over time. Individuals do not evolve because they need to; populations evolve across generations. An adaptation is a trait shaped by past selection that improves reproductive success in a context, and it can be costly elsewhere.' },
  { tags:['computer science','algorithm','complexity','big o','programming'], title:'Computer science: algorithms and complexity', text:'An algorithm is a finite, precise procedure for solving a class of problems. Correctness asks whether it returns the intended result for all allowed inputs. Time and space complexity describe resource growth as input size n grows. Big-O is an asymptotic upper-bound notation, not an exact runtime. For example, scanning a list is O(n); binary search is O(log n) only when the data is ordered and random access is available.' },
  { tags:['recursion','induction','base case','recursive'], title:'Computer science: recursion and induction', text:'A recursive function solves a problem by reducing it to smaller instances and must have a base case that stops. To prove a statement by induction, establish a base case, assume it holds for n=k, then prove it for k+1. Recursion mirrors this structure, but a proof of termination also needs a quantity that decreases toward the base case. Missing base cases cause nontermination or stack errors.' },
  { tags:['economics','supply','demand','equilibrium','elasticity'], title:'Economics: supply and demand', text:'A demand curve relates price to quantity buyers are willing and able to purchase, holding other factors fixed. A supply curve relates price to quantity sellers are willing to provide. Their intersection is a competitive-market equilibrium in the simple model. A change in the good’s own price causes movement along a curve; changed income, costs, expectations, or substitutes can shift a curve. Elasticity measures responsiveness, not moral value.' },
  { tags:['inflation','gdp','unemployment','macroeconomics','interest rate'], title:'Economics: macroeconomic indicators', text:'GDP measures the market value of final goods and services produced within a country over a period; it is not a complete measure of wellbeing. Inflation is a sustained rise in the general price level, commonly estimated with price indexes. Unemployment rates depend on the labor-force definition. Interest rates influence borrowing and saving, but the effects of policy depend on expectations, timing, and economic conditions.' },
  { tags:['grammar','sentence','clause','comma','punctuation'], title:'Writing: sentence structure and punctuation', text:'An independent clause can stand alone; a dependent clause cannot. Join two independent clauses with a period, a semicolon, or a comma plus a coordinating conjunction. A comma splice joins independent clauses with only a comma and is usually incorrect in formal prose. Put commas after introductory elements and around nonessential parenthetical material. Read aloud to find awkward rhythm, then verify grammar rather than relying only on sound.' },
  { tags:['thesis','argument','essay','claim','evidence','reasoning'], title:'Writing: building an argument', text:'A strong argument makes a specific, debatable claim and supports it with relevant evidence and reasoning. A useful paragraph often states a point, presents evidence, explains how the evidence supports the point, and connects it to the larger argument. Address the strongest counterargument fairly. Distinguish quotation, paraphrase, and your own analysis, and cite sources using the required style.' },
  { tags:['rhetoric','ethos','pathos','logos','audience'], title:'Writing: rhetorical appeals', text:'Ethos concerns a speaker’s credibility; pathos concerns emotional appeal; logos concerns reasoning and evidence. These are lenses for analysis, not automatic proof that a claim is true or false. Identify the audience, purpose, context, choices of language and structure, and their likely effects. Support interpretations with specific details from the text.' },
  { tags:['history','primary source','secondary source','historical method'], title:'History: evaluating evidence', text:'A primary source comes from the period or event being studied; a secondary source interprets evidence later. “Primary” does not mean unbiased or automatically accurate. Ask who created a source, when, for whom, for what purpose, what it omits, and how it compares with other evidence. Separate what the source directly shows from an inference about the past.' },
  { tags:['scientific method','hypothesis','experiment','control','causation'], title:'Science: experiments and causal claims', text:'A hypothesis is a testable proposed explanation or prediction. A controlled experiment changes an independent variable and measures a dependent variable while holding relevant conditions steady. Random assignment helps balance confounders; replication tests reliability. Correlation alone does not establish causation because of confounding, reverse causality, or coincidence. Ethical and practical constraints sometimes require observational evidence instead.' },
  { tags:['hello','hi','greeting','hey','good morning'], title:'Hello', text:'Hi! I’m Nova. I can answer selected questions using this offline lesson library, use Chrome’s on-device model if your Chrome supports it, read the page when you request it, and help with reversible page styling. What would you like to work on?' }
];

function normalize(text) { return String(text || '').toLowerCase().replace(/[^a-z0-9+*/^().\s-]/g, ' ').replace(/\s+/g, ' ').trim(); }
function extractQuestion(text) {
  const s=String(text||'');
  const m=s.match(/(?:user(?:'s)? question|question|task|request):\s*([^\n]+)/i);
  return (m?.[1] || s.slice(0,1600)).trim();
}
function hasTag(q, tag) {
  const needle=normalize(tag);
  if(!needle)return false;
  const escaped=needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(?:^|\\s)${escaped}(?:$|\\s)`).test(q);
}
function retrieve(text, limit=3) {
  const q=normalize(extractQuestion(text));
  if(!q)return [];
  return LESSONS.map((lesson,index)=>{
    const score=lesson.tags.reduce((sum,tag)=>sum+(hasTag(q,tag) ? Math.max(1,normalize(tag).split(' ').length) : 0),0);
    return {lesson,index,score};
  }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.index-b.index).slice(0,limit).map(x=>x.lesson);
}
function calculate(question) {
  let raw=String(question||'').replace(/,/g,'').replace(/\n\s*Requested explanation level:[\s\S]*$/i,'').trim();
  const match=raw.match(/(?:what is|calculate|compute|evaluate|solve)\s+([-+\d.()\s*/^%]+)\??\s*$/i) || raw.match(/^\s*([-+\d.()\s*/^%]+)\s*=\s*\?\s*$/);
  if(!match)return null;
  const source=match[1].trim();
  if(!source||source.length>120||!/^[\d.()+\-*/^%\s]+$/.test(source))return null;
  const tokens=source.match(/\d+(?:\.\d+)?|\.|[()+\-*/^%]/g)||[];let pos=0;
  const parseExpression=(min=0)=>{
    let token=tokens[pos++];let left;
    if(token==='+'||token==='-')left=parseExpression(30)*(token==='-'?-1:1);
    else if(token==='('){left=parseExpression(0);if(tokens[pos++]!==')')throw Error('paren');}
    else {if(!token||!/^(?:\d+(?:\.\d+)?|\.)$/.test(token))throw Error('number');left=Number(token);if(!Number.isFinite(left))throw Error('number');}
    const bp={'+':10,'-':10,'*':20,'/':20,'%':20,'^':40};
    while(pos<tokens.length){const op=tokens[pos], power=bp[op];if(power===undefined||power<min)break;pos++;const right=parseExpression(power+(op==='^'?0:1));if(op==='+')left+=right;else if(op==='-')left-=right;else if(op==='*')left*=right;else if(op==='/'){if(right===0)throw Error('zero');left/=right;}else if(op==='%'){if(right===0)throw Error('zero');left%=right;}else left=Math.pow(left,right);if(!Number.isFinite(left)||Math.abs(left)>1e100)throw Error('range');}
    return left;
  };
  try{const value=parseExpression();if(pos!==tokens.length)return null;return Number.isInteger(value)?String(value):String(Number(value.toPrecision(12)));}catch{return null;}
}
function extractPageText(text) {
  const m=String(text||'').match(/Text:\s*([\s\S]*?)\s*\[End page context\]/i);
  if(m)return m[1].replace(/\s+/g,' ').trim();
  const n=String(text||'').match(/PAGE:\s*([\s\S]*?)(?:\n[A-Z][A-Z ]{2,}:|$)/);
  return n?.[1]?.slice(0,5000).trim()||'';
}
function simpleSummary(text) {
  const sentences=String(text||'').replace(/\s+/g,' ').split(/(?<=[.!?])\s+/).map(x=>x.trim()).filter(x=>x.length>35);
  if(!sentences.length)return '';
  const chosen=[];for(const s of sentences){if(!chosen.includes(s))chosen.push(s);if(chosen.length===4)break;}
  return chosen.map(x=>`• ${x}`).join('\n');
}
export function knowledgeContext(prompt) {
  const lessons=retrieve(prompt,3);
  return lessons.length?`\n\nCURATED REFERENCE NOTES (helpful source material, not complete coverage):\n${lessons.map(x=>`${x.title}: ${x.text}`).join('\n\n')}\nUse these notes accurately, explain from first principles, and say if the question goes beyond them.`:'';
}
export function answerOffline(prompt) {
  const question=extractQuestion(prompt);
  const norm=normalize(question);
  if(/^(hi|hello|hey|good morning|good afternoon|good evening|how are you)\b/.test(norm))return LESSONS.at(-1).text;
  const result=calculate(question);
  if(result!==null)return `The result is ${result}. I evaluated the expression using order of operations. This offline calculator covers ordinary arithmetic with parentheses, decimals, powers, multiplication, division, and remainders.`;
  const page=extractPageText(prompt);
  if(/summari[sz]e|key points|main idea|central point/i.test(question)&&page){const summary=simpleSummary(page);if(summary)return `Here are key sentences from the page, selected extractively (not newly researched):\n${summary}\n\nThis lightweight offline summary may miss context or nuance.`;}
  if(/explain this selected text|selected text:/i.test(question)){const selected=question.match(/Selected text:\s*([\s\S]*)/i)?.[1];if(selected)return `I can restate the selected passage, but I cannot reliably explain its full context without a language model.\n\nSelected text: “${selected.slice(0,1000)}”\n\nChrome’s on-device AI may be unavailable on this device; the curated offline guide below may help.`;}
  const lessons=retrieve(question,2);
  if(lessons.length)return `Offline guide — ${lessons.map(x=>x.title).join(' · ')}\n\n${lessons.map(x=>x.text).join('\n\n')}\n\nThis is a concise built-in reference, not a trained MIT/Harvard-level model. For a longer explanation or problems outside these notes, Chrome’s on-device model must be available.`;
  return `I’m in offline reference mode, so I can’t generate a reliable answer to that question right now. Chrome’s on-device AI is unavailable, and Nova has no hosted service or API keys. Try a question about arithmetic, calculus basics, linear algebra, introductory physics/chemistry/biology, computer science, economics, statistics, or writing—or check Chrome’s on-device AI availability.`;
}
export const KNOWLEDGE_TOPICS=LESSONS.map(x=>x.title);
